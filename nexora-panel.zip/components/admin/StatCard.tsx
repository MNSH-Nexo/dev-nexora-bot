import { LucideIcon } from "lucide-react";

type Accent = "blue" | "violet" | "green" | "orange";

const accentMap: Record<Accent, { bg: string; border: string; icon: string; glow: string }> = {
  blue:   { bg: "bg-blue-500/10",   border: "border-blue-500/25",   icon: "text-blue-400",   glow: "shadow-blue-500/10" },
  violet: { bg: "bg-violet-500/10", border: "border-violet-500/25", icon: "text-violet-400", glow: "shadow-violet-500/10" },
  green:  { bg: "bg-emerald-500/10",border: "border-emerald-500/25",icon: "text-emerald-400",glow: "shadow-emerald-500/10" },
  orange: { bg: "bg-orange-500/10", border: "border-orange-500/25", icon: "text-orange-400", glow: "shadow-orange-500/10" },
};

interface Props {
  icon: LucideIcon;
  label: string;
  value: string;
  sub?: string;
  delay?: number;
  accent?: Accent;
}

export default function StatCard({ icon: Icon, label, value, sub, delay = 0, accent = "blue" }: Props) {
  const a = accentMap[accent];
  return (
    <div
      className={`animate-in-up rounded-2xl border ${a.border} ${a.bg} p-4 shadow-lg ${a.glow} transition-all duration-200 hover:scale-[1.02] cursor-default`}
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center bg-background/40 border ${a.border}`}>
          <Icon className={`w-4.5 h-4.5 ${a.icon}`} size={18} />
        </div>
      </div>
      <p className="text-2xl font-bold text-foreground mt-3 tabular-nums">{value}</p>
      <p className="text-xs font-medium text-muted-foreground mt-0.5">{label}</p>
      {sub && <p className="text-[11px] text-muted-foreground/60 mt-1">{sub}</p>}
    </div>
  );
}
