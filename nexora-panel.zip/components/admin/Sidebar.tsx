"use client";
import { apiFetch } from "@/lib/api";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, useCallback } from "react";
import Image from "next/image";
import {
  LayoutDashboard, Package, Users, CreditCard, Ticket,
  Settings, Shield, ChevronRight, Tag, Megaphone, Server,
  Gift, UserPlus, Lock, X, Menu,
} from "lucide-react";

const NAV_PATHS = [
  { path: "/dashboard",              icon: LayoutDashboard, label: "داشبورد",        group: null },
  { path: "/dashboard/plans",        icon: Package,         label: "پلن‌ها",          group: "مدیریت" },
  { path: "/dashboard/discounts",    icon: Tag,             label: "کدهای تخفیف",    group: "مدیریت" },
  { path: "/dashboard/test-sub",     icon: Gift,            label: "اشتراک تست",      group: "مدیریت" },
  { path: "/dashboard/users",        icon: Users,           label: "کاربران",         group: "مدیریت" },
  { path: "/dashboard/manual-sub",   icon: UserPlus,        label: "اشتراک دستی",     group: "مدیریت" },
  { path: "/dashboard/payments",     icon: CreditCard,      label: "تراکنش‌ها",       group: "مالی" },
  { path: "/dashboard/tickets",      icon: Ticket,          label: "تیکت‌ها",         group: "پشتیبانی" },
  { path: "/dashboard/broadcast",    icon: Megaphone,       label: "پیام دسته‌جمعی", group: "پشتیبانی" },
  { path: "/dashboard/server",       icon: Server,          label: "سرور و بک‌آپ",   group: "سیستم" },
  { path: "/dashboard/settings",     icon: Settings,        label: "تنظیمات",         group: "سیستم" },
  { path: "/dashboard/security",     icon: Lock,            label: "امنیت",           group: "سیستم" },
];

function getWebPrefix(pathname: string): string {
  const dashIdx = pathname.indexOf("/dashboard");
  if (dashIdx > 0) return pathname.slice(0, dashIdx);
  const loginIdx = pathname.indexOf("/login");
  if (loginIdx > 0) return pathname.slice(0, loginIdx);
  return "";
}

function SidebarContent({
  prefix, pathname, onLinkClick, panelName, logoUrl,
}: { prefix: string; pathname: string; onLinkClick?: () => void; panelName: string; logoUrl: string }) {
  const NAV = NAV_PATHS.map(item => ({ ...item, href: `${prefix}${item.path}` }));

  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="h-16 flex items-center px-5 border-b border-sidebar-border gap-3 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center overflow-hidden shrink-0">
          {logoUrl
            ? <Image src={logoUrl} alt="logo" width={32} height={32} className="w-full h-full object-cover" unoptimized />
            : <Shield className="w-4 h-4 text-primary" />
          }
        </div>
        <div>
          <p className="text-sm font-bold text-foreground tracking-wide">{panelName || "NEXORA"}</p>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Admin Panel</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 px-3 overflow-y-auto">
        {(() => {
          const rendered: React.ReactNode[] = [];
          let lastGroup: string | null = undefined as unknown as string;
          NAV.forEach(({ href, icon: Icon, label, group }) => {
            if (group !== lastGroup) {
              if (group) rendered.push(
                <p key={`g-${group}`} className="text-[10px] uppercase tracking-widest text-muted-foreground/40 px-3 pt-3 pb-1 font-semibold">{group}</p>
              );
              lastGroup = group;
            }
            const active = pathname === href || (href !== `${prefix}/dashboard` && pathname.startsWith(href));
            rendered.push(
              <Link key={href} href={href} onClick={onLinkClick}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150 group mb-0.5 ${
                  active ? "nav-active text-primary font-semibold" : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent"
                }`}>
                <Icon className={`w-4 h-4 shrink-0 ${active ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`} />
                <span className="flex-1">{label}</span>
                {active && <ChevronRight className="w-3 h-3 text-primary opacity-60" />}
              </Link>
            );
          });
          return rendered;
        })()}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border shrink-0 space-y-2">
        <div className="flex items-center gap-2 px-2">
          <div className="w-2 h-2 rounded-full bg-green-400 pulse-dot" />
          <span className="text-xs text-muted-foreground">ربات آنلاین</span>
        </div>
        <a href="https://github.com/MNSH-Nexo" target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-sidebar-accent transition-colors group">
          {/* GitHub SVG icon */}
          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 text-muted-foreground group-hover:text-foreground transition-colors fill-current" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>
          </svg>
          <span className="text-[10px] text-muted-foreground group-hover:text-foreground transition-colors">ساخته شده توسط MNSH-Nexo</span>
        </a>
      </div>
    </div>
  );
}

export default function Sidebar() {
  const pathname = usePathname();
  const prefix = getWebPrefix(pathname);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [panelName, setPanelName]   = useState("NEXORA");
  const [logoUrl, setLogoUrl]       = useState("");

  const refreshBrand = useCallback(() => {
    apiFetch("/api/brand")
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        if (d) {
          setPanelName(d.panelName ?? "NEXORA");
          // لوگو URL — باید webpath prefix داشته باشد تا Next.js درست route کند
          const raw = d.logoUrl ?? "";
          if (raw) {
            const prefix = getWebPrefix(window.location.pathname);
            // اگه URL قبلاً absolute یا با prefix شروع می‌شود، دوباره اضافه نکن
            const full = raw.startsWith("http") || (prefix && raw.startsWith(prefix))
              ? raw
              : prefix + raw;
            setLogoUrl(full);
          } else {
            setLogoUrl("");
          }
        }
      })
      .catch(() => {});
  }, []);

  // بارگذاری اولیه
  useEffect(() => { refreshBrand(); }, [refreshBrand]);

  // گوش دادن به BroadcastChannel — وقتی settings brand را ذخیره کرد
  useEffect(() => {
    try {
      const bc = new BroadcastChannel("nexora_brand");
      bc.onmessage = (e) => {
        if (e.data?.type === "brand_updated") refreshBrand();
      };
      return () => bc.close();
    } catch { /* BroadcastChannel پشتیبانی نشد — مهم نیست */ }
  }, [refreshBrand]);

  // Close drawer on route change
  useEffect(() => { setMobileOpen(false); }, [pathname]);

  // Prevent body scroll when drawer open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-64 shrink-0 flex-col min-h-screen bg-sidebar border-l border-sidebar-border">
        <SidebarContent prefix={prefix} pathname={pathname} panelName={panelName} logoUrl={logoUrl} />
      </aside>

      {/* Mobile: hamburger button (rendered in TopBar via portal-like approach — placed here as fixed) */}
      <button
        onClick={() => setMobileOpen(true)}
        className="lg:hidden fixed top-3.5 right-4 z-40 w-9 h-9 rounded-xl bg-sidebar border border-sidebar-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        aria-label="باز کردن منو"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile: backdrop */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-background/70 backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile: drawer */}
      <aside
        className={`lg:hidden fixed top-0 right-0 z-50 h-full w-72 bg-sidebar border-l border-sidebar-border
          transform transition-transform duration-300 ease-in-out
          ${mobileOpen ? "translate-x-0" : "translate-x-full"}`}
      >
        <button
          onClick={() => setMobileOpen(false)}
          className="absolute top-4 left-4 w-8 h-8 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
        <SidebarContent prefix={prefix} pathname={pathname} onLinkClick={() => setMobileOpen(false)} panelName={panelName} logoUrl={logoUrl} />
      </aside>
    </>
  );
}
