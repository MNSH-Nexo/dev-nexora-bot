"use client";
import { apiFetch } from "@/lib/api";
import { useRef, useState } from "react";
import {
  Server, RefreshCw, Archive, CheckCircle2, Upload,
  Trash2, AlertTriangle, AlertCircle, Database,
  RotateCcw, Bot, Monitor, Layers,
} from "lucide-react";

type BackupResult = { ok: boolean; results?: string[]; error?: string };
type RestoreResult = { ok: boolean; message?: string; error?: string };
type RestartResult = { ok: boolean; results?: Array<{ label: string; ok: boolean; out: string }>; error?: string };

export default function ServerPage() {
  // Restart
  const [restartLoading, setRestartLoading] = useState<string | null>(null);
  const [restartResult, setRestartResult]   = useState<RestartResult | null>(null);

  // Backup
  const [backupLoading, setBackupLoading] = useState<string | null>(null);
  const [backupResult, setBackupResult]   = useState<BackupResult | null>(null);

  // Restore
  const fileRef = useRef<HTMLInputElement>(null);
  const [restoreFile, setRestoreFile]     = useState<File | null>(null);
  const [restoreLoading, setRestoreLoading] = useState(false);
  const [restoreResult, setRestoreResult] = useState<RestoreResult | null>(null);

  // Reset
  const [resetStep, setResetStep] = useState<0|1|2>(0); // 0=idle 1=confirm1 2=confirm2
  const [resetLoading, setResetLoading] = useState(false);
  const [resetResult, setResetResult]   = useState<{ ok: boolean; message?: string; error?: string } | null>(null);

  // ── Restart ───────────────────────────────────────────────
  const doRestart = async (target: string) => {
    setRestartLoading(target); setRestartResult(null);
    try {
      const res = await apiFetch("/api/restart", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target }),
      });
      setRestartResult(await res.json());
    } catch { setRestartResult({ ok: false, error: "خطا در اتصال" }); }
    finally { setRestartLoading(null); setTimeout(() => setRestartResult(null), 8000); }
  };

  // ── Backup ────────────────────────────────────────────────
  const doBackup = async (action: string) => {
    setBackupLoading(action); setBackupResult(null);
    try {
      const res = await apiFetch("/api/backup", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      setBackupResult(await res.json());
    } catch { setBackupResult({ ok: false, error: "خطا در اتصال" }); }
    finally { setBackupLoading(null); setTimeout(() => setBackupResult(null), 6000); }
  };

  // ── Restore ───────────────────────────────────────────────
  const doRestore = async () => {
    if (!restoreFile) return;
    if (!confirm("آیا مطمئن هستید؟ دیتابیس فعلی با فایل آپلودی جایگزین می‌شود.")) return;
    setRestoreLoading(true); setRestoreResult(null);
    try {
      const form = new FormData();
      form.append("file", restoreFile);
      const res = await apiFetch("/api/backup", { method: "POST", body: form });
      const d = await res.json();
      setRestoreResult(d);
      if (d.ok) { setRestoreFile(null); if (fileRef.current) fileRef.current.value = ""; }
    } catch { setRestoreResult({ ok: false, error: "خطا در آپلود" }); }
    finally { setRestoreLoading(false); }
  };

  // ── Reset ─────────────────────────────────────────────────
  const doReset = async () => {
    setResetLoading(true); setResetResult(null);
    try {
      const res = await apiFetch("/api/backup", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "reset_confirm" }),
      });
      const d = await res.json();
      setResetResult(d);
      setResetStep(0);
    } catch { setResetResult({ ok: false, error: "خطا در اتصال" }); }
    finally { setResetLoading(false); }
  };

  return (
    <div className="space-y-6">
      <div className="animate-in-up" style={{ animationDelay: "0ms" }}>
        <h1 className="text-xl font-bold text-foreground">سرور و بک‌آپ</h1>
        <p className="text-sm text-muted-foreground mt-0.5">پشتیبان‌گیری، بازگردانی، ری‌استارت و مدیریت دیتابیس ربات</p>
      </div>

      {/* ── Restart ── */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "40ms" }}>
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <RotateCcw className="w-4 h-4 text-primary" /> ری‌استارت سرویس‌ها
        </h2>
        <p className="text-xs text-muted-foreground">
          بعد از تغییر تنظیمات (از جمله فایل .env)، سرویس مربوطه را ری‌استارت کنید تا تغییرات اعمال شود.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {[
            { target: "bot",   label: "ری‌استارت ربات",   icon: Bot,     color: "hover:border-blue-500/40 hover:text-blue-400" },
            { target: "panel", label: "ری‌استارت وب‌پنل", icon: Monitor, color: "hover:border-violet-500/40 hover:text-violet-400" },
            { target: "both",  label: "ری‌استارت هر دو",  icon: Layers,  color: "hover:border-primary/40 hover:text-primary" },
          ].map(({ target, label, icon: Icon, color }) => (
            <button key={target} onClick={() => doRestart(target)}
              disabled={!!restartLoading}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                restartLoading === target
                  ? "bg-primary/10 border-primary/30 text-primary"
                  : `bg-secondary border-border text-muted-foreground ${color} disabled:opacity-50`
              }`}>
              {restartLoading === target
                ? <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                : <Icon className="w-3.5 h-3.5" />}
              {restartLoading === target ? "در حال ری‌استارت..." : label}
            </button>
          ))}
        </div>
        {restartResult && (
          <div className="space-y-1.5">
            {restartResult.results?.map((r, i) => (
              <div key={i} className={`rounded-xl px-4 py-2.5 text-xs border ${
                r.ok ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
                     : "bg-red-500/10 border-red-500/20 text-red-300"
              }`}>
                <p className="font-semibold">{r.label}</p>
                {r.out && <p className="opacity-70 mt-0.5">{r.out}</p>}
              </div>
            ))}
            {restartResult.error && (
              <div className="rounded-xl px-4 py-2.5 text-xs border bg-red-500/10 border-red-500/20 text-red-300">
                {restartResult.error}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── Backup ── */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "60ms" }}>
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Archive className="w-4 h-4 text-primary" /> پشتیبان‌گیری
        </h2>
        <p className="text-xs text-muted-foreground">فایل بک‌آپ از طریق ربات تلگرام به ادمین‌ها ارسال می‌شود. بک‌آپ خودکار هر شب ساعت ۲:۰۰ UTC انجام می‌شود.</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {[
            { action: "backup_bot",   label: "بک‌آپ دیتابیس ربات", icon: "💾" },
            { action: "backup_panel", label: "بک‌آپ تنظیمات پنل",  icon: "🖥" },
            { action: "backup_both",  label: "هر دو با هم",         icon: "📦" },
          ].map((b) => (
            <button key={b.action} onClick={() => doBackup(b.action)}
              disabled={!!backupLoading}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                backupLoading === b.action
                  ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-400"
                  : "bg-secondary border-border text-muted-foreground hover:text-foreground hover:border-primary/40 disabled:opacity-50"
              }`}>
              <span>{b.icon}</span>
              {backupLoading === b.action
                ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" />در حال ارسال...</>
                : b.label}
            </button>
          ))}
        </div>
        {backupResult && (
          <div className={`rounded-xl px-4 py-3 text-xs border space-y-1 ${
            backupResult.ok ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
              : "bg-red-500/10 border-red-500/20 text-red-300"
          }`}>
            {backupResult.results?.map((r, i) => <p key={i}>{r}</p>)}
            {backupResult.error && <p>{backupResult.error}</p>}
          </div>
        )}
      </div>

      {/* ── Restore ── */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "120ms" }}>
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Upload className="w-4 h-4 text-primary" /> بازگردانی دیتابیس ربات
        </h2>
        <p className="text-xs text-muted-foreground">فایل SQLite بک‌آپ را آپلود کنید تا دیتابیس ربات بازگردانی شود. قبل از جایگزینی، یک بک‌آپ خودکار ساخته می‌شود.</p>
        <div className="flex items-center gap-3 flex-wrap">
          <input ref={fileRef} type="file" accept=".db,.sqlite,.sqlite3"
            onChange={e => setRestoreFile(e.target.files?.[0] ?? null)}
            className="flex-1 text-sm text-muted-foreground file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border file:border-border file:bg-secondary file:text-xs file:font-medium file:text-foreground file:cursor-pointer hover:file:border-primary/50 transition-colors" />
          <button onClick={doRestore} disabled={!restoreFile || restoreLoading}
            className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
              restoreFile && !restoreLoading
                ? "bg-primary/15 border-primary/40 text-primary hover:bg-primary/25"
                : "bg-secondary border-border text-muted-foreground cursor-not-allowed opacity-50"
            }`}>
            {restoreLoading ? <><RefreshCw className="w-4 h-4 animate-spin" />در حال بازگردانی...</>
              : <><Database className="w-4 h-4" />بازگردانی</>}
          </button>
        </div>
        {restoreResult && (
          <div className={`rounded-xl px-4 py-3 text-xs border ${
            restoreResult.ok ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
              : "bg-red-500/10 border-red-500/20 text-red-300"
          }`}>
            {restoreResult.ok ? <CheckCircle2 className="w-3.5 h-3.5 inline ml-1" /> : <AlertCircle className="w-3.5 h-3.5 inline ml-1" />}
            {restoreResult.message ?? restoreResult.error}
          </div>
        )}
      </div>

      {/* ── Reset ── */}
      <div className="animate-in-up rounded-2xl border border-red-500/20 bg-card p-5 space-y-4" style={{ animationDelay: "180ms" }}>
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Trash2 className="w-4 h-4 text-red-400" /> ریست کامل دیتابیس
        </h2>
        <div className="bg-red-500/8 border border-red-500/20 rounded-xl px-4 py-3 text-xs text-red-300 space-y-1">
          <p className="font-semibold flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5" /> این عملیات غیرقابل بازگشت است!</p>
          <p>تمام کاربران، اشتراک‌ها، پرداخت‌ها و تیکت‌ها پاک می‌شوند.</p>
          <p>پلن‌ها، کدهای تخفیف و تنظیمات ربات حفظ می‌شوند.</p>
          <p>قبل از ریست، یک بک‌آپ خودکار روی سرور ذخیره می‌شود.</p>
        </div>
        {resetResult && (
          <div className={`rounded-xl px-4 py-3 text-xs border ${
            resetResult.ok ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
              : "bg-red-500/10 border-red-500/20 text-red-300"
          }`}>
            {resetResult.message ?? resetResult.error}
          </div>
        )}
        {resetStep === 0 && (
          <button onClick={() => setResetStep(1)}
            className="px-4 py-2 rounded-xl text-sm font-medium border border-red-500/30 bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors">
            🗑 ریست دیتابیس ربات
          </button>
        )}
        {resetStep === 1 && (
          <div className="space-y-3">
            <p className="text-sm font-semibold text-red-300">⚠️ آیا مطمئن هستید؟ این کار تمام داده‌ها را پاک می‌کند.</p>
            <div className="flex gap-2">
              <button onClick={() => setResetStep(2)}
                className="px-4 py-2 rounded-xl text-sm font-medium border border-red-500/40 bg-red-500/15 text-red-400 hover:bg-red-500/25 transition-colors">
                بله، ادامه بده
              </button>
              <button onClick={() => setResetStep(0)}
                className="px-4 py-2 rounded-xl text-sm font-medium border border-border bg-secondary text-muted-foreground hover:text-foreground transition-colors">
                لغو
              </button>
            </div>
          </div>
        )}
        {resetStep === 2 && (
          <div className="space-y-3">
            <p className="text-sm font-semibold text-red-300">🛑 تأیید نهایی — این عمل دیگر قابل بازگشت نیست!</p>
            <div className="flex gap-2">
              <button onClick={doReset} disabled={resetLoading}
                className="px-4 py-2 rounded-xl text-sm font-medium border border-red-600/50 bg-red-600/20 text-red-300 hover:bg-red-600/30 transition-colors disabled:opacity-50 flex items-center gap-2">
                {resetLoading ? <><RefreshCw className="w-4 h-4 animate-spin" />در حال ریست...</> : "✅ بله، دیتابیس را ریست کن"}
              </button>
              <button onClick={() => setResetStep(0)}
                className="px-4 py-2 rounded-xl text-sm font-medium border border-border bg-secondary text-muted-foreground hover:text-foreground transition-colors">
                ❌ انصراف — نگه دار
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

