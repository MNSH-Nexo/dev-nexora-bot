"use client";
import { apiFetch } from "@/lib/api";
import { useEffect, useState, useCallback } from "react";
import { Gift, ToggleLeft, ToggleRight, Save, Wifi, CheckCircle2, RefreshCw, AlertCircle } from "lucide-react";

type Inbound = { id: number; remark: string; protocol: string; port: number; };

const protoColor: Record<string, string> = {
  vless:  "bg-blue-500/15 border-blue-500/25 text-blue-400",
  vmess:  "bg-violet-500/15 border-violet-500/25 text-violet-400",
  trojan: "bg-orange-500/15 border-orange-500/25 text-orange-400",
};

export default function TestSubPage() {
  const [enabled, setEnabled]     = useState(true);
  const [trafficGb, setTrafficGb] = useState("1");
  const [days, setDays]           = useState("1");
  const [inboundId, setInboundId] = useState<number | null>(null);
  const [inbounds, setInbounds]   = useState<Inbound[]>([]);
  const [loadingInb, setLoadingInb] = useState(true);
  const [saving, setSaving]       = useState(false);
  const [saved, setSaved]         = useState(false);
  const [error, setError]         = useState<string | null>(null);

  // Load both bot-config (settings) and inbounds in parallel
  const fetchData = useCallback(async () => {
    setLoadingInb(true);
    try {
      const [cfgRes, inbRes] = await Promise.all([
        apiFetch("/api/bot-config"),
        apiFetch("/api/inbounds"),
      ]);
      if (cfgRes.ok) {
        const d = await cfgRes.json();
        const c = d.config ?? {};
        setEnabled(c.test_sub_enabled !== "0");
        if (c.test_sub_traffic_gb) setTrafficGb(c.test_sub_traffic_gb);
        if (c.test_sub_duration_days) setDays(c.test_sub_duration_days);
        // test_sub_inbound_id is stored separately
        if (c.test_sub_inbound_id) setInboundId(Number(c.test_sub_inbound_id));
      }
      if (inbRes.ok) {
        const d = await inbRes.json();
        const list: Inbound[] = (d.inbounds ?? []).map((i: Record<string, unknown>) => ({
          id: Number(i.id), remark: String(i.remark ?? `#${i.id}`),
          protocol: String(i.protocol ?? "unknown"), port: Number(i.port ?? 0),
        }));
        setInbounds(list);
        // Auto-select first if none chosen yet
        if (!inboundId && list.length > 0) setInboundId(list[0].id);
      }
    } finally {
      setLoadingInb(false);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleSave = async () => {
    setSaving(true); setError(null);
    try {
      const res = await apiFetch("/api/bot-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          test_sub_enabled:    enabled ? "1" : "0",
          test_sub_traffic_gb: trafficGb,
          test_sub_duration_days: days,
          test_sub_inbound_id: inboundId?.toString() ?? "",
        }),
      });
      if (res.ok) { setSaved(true); setTimeout(() => setSaved(false), 2500); }
      else { const d = await res.json(); setError(d.error ?? "خطا در ذخیره"); }
    } catch { setError("خطا در اتصال"); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="animate-in-up flex items-center justify-between" style={{ animationDelay: "0ms" }}>
        <div>
          <h1 className="text-xl font-bold text-foreground">اشتراک تست رایگان</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            هر کاربر فقط یک بار می‌تواند اشتراک تست دریافت کند
          </p>
        </div>
        <button onClick={fetchData} disabled={loadingInb}
          className="p-2 rounded-lg border border-border hover:border-primary/50 text-muted-foreground hover:text-primary transition-colors disabled:opacity-50">
          <RefreshCw className={`w-4 h-4 ${loadingInb ? "animate-spin" : ""}`} />
        </button>
      </div>

      {error && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-xl border border-red-500/30 bg-red-500/8 text-red-300 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />{error}
        </div>
      )}

      {/* Enable/disable */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5" style={{ animationDelay: "50ms" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center">
              <Gift className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">وضعیت اشتراک تست</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {enabled ? "کاربران می‌توانند اشتراک تست دریافت کنند" : "اشتراک تست غیرفعال است"}
              </p>
            </div>
          </div>
          <button onClick={() => setEnabled(!enabled)}>
            {enabled
              ? <ToggleRight className="w-10 h-10 text-primary" />
              : <ToggleLeft  className="w-10 h-10 text-muted-foreground" />}
          </button>
        </div>
      </div>

      {/* Volume and duration */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "100ms" }}>
        <h2 className="text-sm font-semibold text-foreground">مشخصات اشتراک تست</h2>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: "حجم (گیگابایت)", value: trafficGb, set: setTrafficGb, unit: "GB" },
            { label: "مدت (روز)",       value: days,      set: setDays,       unit: "روز" },
          ].map(({ label, value, set, unit }) => (
            <div key={unit}>
              <label className="text-xs text-muted-foreground mb-1.5 block">{label}</label>
              <div className="flex items-center gap-2">
                <input value={value} onChange={e => set(e.target.value)} type="number" min="1" dir="ltr"
                  className="flex-1 px-3 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground font-mono focus:outline-none focus:border-primary/50 transition-colors" />
                <span className="text-xs text-muted-foreground shrink-0">{unit}</span>
              </div>
            </div>
          ))}
        </div>
        <div className="bg-secondary/30 rounded-xl px-4 py-3 border border-border/40">
          <p className="text-xs text-muted-foreground">
            اشتراک تست: <span className="text-foreground font-semibold">{trafficGb || "1"} GB</span> به مدت{" "}
            <span className="text-foreground font-semibold">{days || "1"} روز</span>
          </p>
        </div>
      </div>

      {/* Inbound selection — real from panel */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "150ms" }}>
        <div>
          <h2 className="text-sm font-semibold text-foreground">اینباند اشتراک تست</h2>
          <p className="text-xs text-muted-foreground mt-0.5">اینباندی که برای کانفیگ تست استفاده می‌شود</p>
        </div>

        {loadingInb ? (
          <div className="space-y-2">
            {[1,2,3].map(i => <div key={i} className="h-14 rounded-xl border border-border/30 bg-card/40 animate-pulse" />)}
          </div>
        ) : inbounds.length === 0 ? (
          <div className="px-4 py-3 rounded-xl border border-yellow-500/20 bg-yellow-500/8 text-yellow-300 text-xs">
            پنل 3X-UI در دسترس نیست — پس از تنظیم PANEL_URL در .env.local پنل دوباره تلاش کنید.
          </div>
        ) : (
          <div className="grid gap-2">
            {inbounds.map((inb) => {
              const sel = inboundId === inb.id;
              return (
                <button key={inb.id} onClick={() => setInboundId(inb.id)}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-right transition-all ${
                    sel ? "border-primary/50 bg-primary/8" : "border-border/50 bg-background/40 hover:border-border"
                  }`}>
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                    <Wifi className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0 text-right">
                    <p className={`text-sm font-medium ${sel ? "text-primary" : "text-foreground"}`}>{inb.remark}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                        {inb.protocol.toUpperCase()}
                      </span>
                      <span className="text-xs text-muted-foreground">پورت: {inb.port}</span>
                    </div>
                  </div>
                  <div className={`w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center ${sel ? "border-primary bg-primary" : "border-border"}`}>
                    {sel && <CheckCircle2 className="w-3 h-3 text-primary-foreground" />}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {!inboundId && inbounds.length > 0 && (
          <p className="text-xs text-yellow-400 bg-yellow-500/10 border border-yellow-500/20 rounded-xl px-3 py-2">
            ⚠️ هیچ اینباندی انتخاب نشده — اشتراک تست ساخته نمی‌شود
          </p>
        )}
      </div>

      <div className="animate-in-up rounded-2xl border border-border/40 bg-secondary/20 px-4 py-3" style={{ animationDelay: "200ms" }}>
        <p className="text-xs text-muted-foreground leading-relaxed">
          💡 هر کاربر فقط <span className="text-foreground font-semibold">یک بار</span> می‌تواند از اشتراک تست استفاده کند.
          اینباند تست از اینباندهای پلن‌های معمولی مجزا است.
        </p>
      </div>

      <div className="animate-in-up pb-4" style={{ animationDelay: "250ms" }}>
        <button onClick={handleSave} disabled={saving}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            saved ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              : "bg-primary text-primary-foreground hover:bg-primary/90"
          }`}>
          <Save className="w-4 h-4" />
          {saved ? "ذخیره شد ✓" : saving ? "در حال ذخیره..." : "ذخیره تنظیمات"}
        </button>
      </div>
    </div>
  );
}
