"use client";
import { apiFetch } from "@/lib/api";
import { useEffect, useState, useCallback } from "react";
import {
  Plus, Pencil, Trash2, ToggleLeft, ToggleRight,
  Package, Infinity, X, Save, Wifi, RefreshCw, AlertCircle,
} from "lucide-react";

interface Inbound { id: number; remark: string; protocol: string; port: number; }
interface Plan {
  id: number; name: string; traffic_gb: number; duration_days: number;
  price_usdt: number; limit_ip: number; inbound_ids: number[];
  is_active: boolean; sort_order: number;
}

const protoColor: Record<string, string> = {
  vless:  "bg-blue-500/15 border-blue-500/25 text-blue-400",
  vmess:  "bg-violet-500/15 border-violet-500/25 text-violet-400",
  trojan: "bg-orange-500/15 border-orange-500/25 text-orange-400",
};

const emptyEdit = (): Omit<Plan, "id"> => ({
  name: "", traffic_gb: 0, duration_days: 30, price_usdt: 0,
  limit_ip: 0, inbound_ids: [], is_active: true, sort_order: 0,
});


// ── PlanForm ─────────────────────────────────────────────────
function PlanForm({
  data, setData, onSave, onCancel, title, saving, inbounds, usdtRate,
}: {
  data: Omit<Plan, "id">;
  setData: (fn: (prev: Omit<Plan, "id">) => Omit<Plan, "id">) => void;
  onSave: () => void; onCancel: () => void; title: string;
  saving: boolean; inbounds: Inbound[]; usdtRate: number;
}) {
  // حالت ورود قیمت: "usdt" | "rial"
  const [priceMode, setPriceMode] = useState<"usdt" | "rial">("rial");
  const [rialInput, setRialInput] = useState(
    data.price_usdt > 0 && usdtRate > 0
      ? String(Math.round(data.price_usdt * usdtRate))
      : ""
  );

  // وقتی ریال تغییر کرد → USDT رو محاسبه و در data ذخیره کن
  const handleRialChange = (val: string) => {
    const cleaned = val.replace(/[^0-9]/g, "");
    setRialInput(cleaned);
    const rial = Number(cleaned);
    if (rial > 0 && usdtRate > 0) {
      const usdt = parseFloat((rial / usdtRate).toFixed(2));
      setData(p => ({ ...p, price_usdt: usdt }));
    } else {
      setData(p => ({ ...p, price_usdt: 0 }));
    }
  };

  // وقتی USDT تغییر کرد → rial preview رو بروز کن
  const handleUsdtChange = (val: number) => {
    setData(p => ({ ...p, price_usdt: val }));
    if (val > 0 && usdtRate > 0) {
      setRialInput(String(Math.round(val * usdtRate)));
    }
  };

  const toggleInb = (id: number) =>
    setData(p => ({
      ...p,
      inbound_ids: p.inbound_ids.includes(id)
        ? p.inbound_ids.filter(x => x !== id)
        : [...p.inbound_ids, id],
    }));

  const rialPreview = data.price_usdt > 0 && usdtRate > 0
    ? Math.round(data.price_usdt * usdtRate).toLocaleString("fa-IR")
    : null;
  const usdtPreview = rialInput && usdtRate > 0
    ? (Number(rialInput) / usdtRate).toFixed(2)
    : null;

  return (
    <div className="animate-in-up rounded-2xl border border-primary/30 bg-primary/5 p-5 space-y-4">
      <p className="text-sm font-semibold text-foreground">{title}</p>

      {/* نام پلن */}
      <div>
        <label className="text-xs text-muted-foreground mb-1 block">نام پلن *</label>
        <input value={data.name}
          onChange={e => setData(p => ({ ...p, name: e.target.value }))}
          placeholder="مثال: ۲۰ گیگ — ۱ ماهه"
          className="w-full px-3 py-2 rounded-xl bg-input border border-border text-sm text-foreground focus:outline-none focus:border-primary/60 transition-colors" />
      </div>

      {/* فیلدهای عددی */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {[
          { label: "حجم (GB) — 0=نامحدود", key: "traffic_gb" as const, min: 0 },
          { label: "مدت (روز)",             key: "duration_days" as const, min: 1 },
          { label: "حد دستگاه (0=نامحدود)", key: "limit_ip" as const, min: 0 },
        ].map(({ label, key, min }) => (
          <div key={key}>
            <label className="text-xs text-muted-foreground mb-1 block">{label}</label>
            <input value={data[key]} type="number" min={min} step="1" dir="ltr"
              onChange={e => setData(p => ({ ...p, [key]: Number(e.target.value) }))}
              className="w-full px-3 py-2 rounded-xl bg-input border border-border text-sm font-mono text-foreground focus:outline-none focus:border-primary/60 transition-colors" />
          </div>
        ))}
      </div>

      {/* قیمت — ریالی یا دلاری */}
      <div className="rounded-xl border border-border/60 bg-background/40 p-3 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-medium text-foreground">قیمت پلن *</label>
          <div className="flex gap-1 bg-secondary rounded-lg p-0.5">
            <button onClick={() => setPriceMode("rial")}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${priceMode === "rial" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
              تومان
            </button>
            <button onClick={() => setPriceMode("usdt")}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${priceMode === "usdt" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
              USDT
            </button>
          </div>
        </div>

        {priceMode === "rial" ? (
          <div>
            <div className="relative">
              <input value={rialInput} type="text" inputMode="numeric" dir="ltr" placeholder="مثال: 500000"
                onChange={e => handleRialChange(e.target.value)}
                className="w-full px-3 py-2 pr-16 rounded-xl bg-input border border-border text-sm font-mono text-foreground focus:outline-none focus:border-primary/60 transition-colors" />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">تومان</span>
            </div>
            {usdtRate > 0 && usdtPreview && Number(usdtPreview) > 0 && (
              <p className="text-xs text-emerald-400/80 mt-1.5">
                ≈ <span className="font-mono font-semibold">{usdtPreview}</span> USDT
                {" "}(نرخ: {usdtRate.toLocaleString("fa-IR")} تومان)
              </p>
            )}
            {usdtRate === 0 && (
              <p className="text-xs text-yellow-400/70 mt-1.5">⚠️ نرخ دلار تنظیم نشده — ابتدا از تنظیمات نرخ را وارد کنید</p>
            )}
          </div>
        ) : (
          <div>
            <div className="relative">
              <input value={data.price_usdt || ""} type="number" min={0} step="0.01" dir="ltr" placeholder="مثال: 5.00"
                onChange={e => handleUsdtChange(Number(e.target.value))}
                className="w-full px-3 py-2 pr-16 rounded-xl bg-input border border-border text-sm font-mono text-foreground focus:outline-none focus:border-primary/60 transition-colors" />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">USDT</span>
            </div>
            {usdtRate > 0 && rialPreview && (
              <p className="text-xs text-emerald-400/80 mt-1.5">
                ≈ <span className="font-mono font-semibold">{rialPreview}</span> تومان
              </p>
            )}
          </div>
        )}
      </div>

      {/* ترتیب و وضعیت */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">ترتیب نمایش</label>
          <input value={data.sort_order} type="number" min="0" dir="ltr"
            onChange={e => setData(p => ({ ...p, sort_order: Number(e.target.value) }))}
            className="w-full px-3 py-2 rounded-xl bg-input border border-border text-sm font-mono text-foreground focus:outline-none focus:border-primary/60 transition-colors" />
        </div>
        <div className="flex items-end pb-0.5">
          <button onClick={() => setData(p => ({ ...p, is_active: !p.is_active }))}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium transition-colors ${
              data.is_active ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-400"
                : "bg-secondary border-border text-muted-foreground"
            }`}>
            {data.is_active ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
            {data.is_active ? "فعال" : "غیرفعال"}
          </button>
        </div>
      </div>

      {/* اینباندها */}
      <div>
        <label className="text-xs text-muted-foreground mb-2 block">
          اینباندها ({data.inbound_ids.length} انتخاب‌شده)
          {inbounds.length === 0 && <span className="text-yellow-400/70 mr-2">— پنل 3X-UI در دسترس نیست</span>}
        </label>
        {inbounds.length > 0 ? (
          <div className="grid grid-cols-2 gap-2">
            {inbounds.map(inb => {
              const sel = data.inbound_ids.includes(inb.id);
              return (
                <button key={inb.id} onClick={() => toggleInb(inb.id)}
                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-right transition-all ${
                    sel ? "border-primary/50 bg-primary/8" : "border-border/50 bg-background/40 hover:border-border"
                  }`}>
                  <div className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 ${sel ? "border-primary bg-primary" : "border-border"}`}>
                    {sel && <div className="w-2 h-2 bg-white rounded-sm" />}
                  </div>
                  <span className={`text-[10px] font-mono px-1 py-0.5 rounded border shrink-0 ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                    {(inb.protocol ?? "?").slice(0, 1).toUpperCase()}
                  </span>
                  <span className={`text-xs truncate ${sel ? "text-primary" : "text-foreground"}`}>{inb.remark}</span>
                </button>
              );
            })}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground bg-secondary/30 rounded-xl px-3 py-2 border border-border/40">
            اینباندهای 3X-UI در دسترس نیستند — می‌توانید پلن را بدون آن‌ها ذخیره کنید.
          </p>
        )}
      </div>

      <div className="flex gap-2 pt-1">
        <button onClick={onSave} disabled={saving || !data.name || !data.price_usdt}
          className={`flex items-center gap-2 px-5 py-2 rounded-xl text-sm font-semibold transition-all ${
            saving || !data.name || !data.price_usdt
              ? "bg-secondary text-muted-foreground cursor-not-allowed"
              : "bg-primary text-primary-foreground hover:bg-primary/90"
          }`}>
          <Save className="w-4 h-4" />
          {saving ? "در حال ذخیره..." : "ذخیره"}
        </button>
        <button onClick={onCancel}
          className="px-4 py-2 rounded-xl bg-secondary text-muted-foreground text-sm hover:text-foreground transition-colors">
          انصراف
        </button>
      </div>
    </div>
  );
}

// ── Page ─────────────────────────────────────────────────────
export default function PlansPage() {
  const [plans, setPlans]       = useState<Plan[]>([]);
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [usdtRate, setUsdtRate] = useState(0);
  const [loading, setLoading]   = useState(true);
  const [source, setSource]     = useState<string>("loading");
  const [editId, setEditId]     = useState<number | null>(null);
  const [editData, setEditData] = useState<Omit<Plan, "id">>(emptyEdit());
  const [showAdd, setShowAdd]   = useState(false);
  const [newPlan, setNewPlan]   = useState<Omit<Plan, "id">>(emptyEdit());
  const [saving, setSaving]     = useState(false);
  const [error, setError]       = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [pr, ir, sr] = await Promise.all([
        apiFetch("/api/plans"),
        apiFetch("/api/inbounds"),
        apiFetch("/api/settings"),
      ]);
      if (pr.ok) { const d = await pr.json(); setPlans(d.plans ?? []); setSource(d.source ?? "unknown"); }
      if (ir.ok) {
        const d = await ir.json();
        setInbounds((d.inbounds ?? []).map((i: Record<string, unknown>) => ({
          id: i.id, remark: i.remark ?? `#${i.id}`,
          protocol: String(i.protocol ?? "unknown"), port: Number(i.port ?? 0),
        })));
      }
      if (sr.ok) {
        const d = await sr.json();
        // نرخ تومان از تنظیمات (key: usdt_to_toman_rate)
        const rate = Number(d.usdt_to_toman_rate ?? 0);
        setUsdtRate(rate);
      }
    } catch { setError("خطا در دریافت داده‌ها"); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const toggleActive = async (plan: Plan) => {
    await apiFetch("/api/plans", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: plan.id, is_active: !plan.is_active }),
    });
    setPlans(ps => ps.map(p => p.id === plan.id ? { ...p, is_active: !p.is_active } : p));
  };

  const deletePlan = async (id: number) => {
    if (!confirm("آیا مطمئن هستید؟ این عمل قابل بازگشت نیست.")) return;
    await apiFetch(`/api/plans?id=${id}`, { method: "DELETE" });
    setPlans(ps => ps.filter(p => p.id !== id));
  };

  const handleAdd = async () => {
    if (!newPlan.name || !newPlan.price_usdt) return;
    setSaving(true);
    const res = await apiFetch("/api/plans", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newPlan),
    });
    if (res.ok) { setShowAdd(false); setNewPlan(emptyEdit()); await fetchData(); }
    setSaving(false);
  };

  const handleEdit = async () => {
    if (!editId || !editData.name) return;
    setSaving(true);
    const res = await apiFetch("/api/plans", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: editId, ...editData }),
    });
    if (res.ok) {
      // بروزرسانی فوری در state — نام جدید بلافاصله در لیست نمایش داده می‌شود
      const updatedId = editId;
      setPlans(ps => ps.map(p => p.id === updatedId ? { ...p, ...editData } : p));
    }
    setEditId(null);
    await fetchData();
    setSaving(false);
  };

  return (
    <div className="space-y-6">
      <div className="animate-in-up flex items-center justify-between" style={{ animationDelay: "0ms" }}>
        <div>
          <h1 className="text-xl font-bold text-foreground">مدیریت پلن‌ها</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {plans.length} پلن
            {source === "live" && <span className="text-green-400/60 mr-2">• زنده</span>}
            {source === "unavailable" && <span className="text-yellow-400 mr-2">— دیتابیس ربات در دسترس نیست</span>}
            {usdtRate > 0 && <span className="text-muted-foreground/50 mr-2">• نرخ: {usdtRate.toLocaleString("fa-IR")} تومان</span>}
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={fetchData} disabled={loading}
            className="p-2 rounded-lg border border-border hover:border-primary/50 text-muted-foreground hover:text-primary transition-colors disabled:opacity-50">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
          <button onClick={() => { setShowAdd(!showAdd); setNewPlan(emptyEdit()); }}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors">
            {showAdd ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
            {showAdd ? "انصراف" : "پلن جدید"}
          </button>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-xl border border-red-500/30 bg-red-500/8 text-red-300 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />{error}
        </div>
      )}

      {showAdd && (
        <PlanForm data={newPlan} setData={setNewPlan} title="افزودن پلن جدید"
          onSave={handleAdd} onCancel={() => { setShowAdd(false); setNewPlan(emptyEdit()); }}
          saving={saving} inbounds={inbounds} usdtRate={usdtRate} />
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="rounded-2xl border border-border/30 bg-card/40 h-20 animate-pulse" />)}
        </div>
      ) : plans.length === 0 && !showAdd ? (
        <div className="text-center py-12 text-muted-foreground text-sm">هیچ پلنی تعریف نشده</div>
      ) : (
        <div className="animate-in-up grid gap-3" style={{ animationDelay: "60ms" }}>
          {plans.map((plan, i) => {
            const planInbounds = inbounds.filter(inb => plan.inbound_ids.includes(inb.id));
            const isEditing = editId === plan.id;
            const rialPrice = usdtRate > 0 ? Math.round(plan.price_usdt * usdtRate).toLocaleString("fa-IR") : null;
            return (
              <div key={plan.id}
                className={`rounded-2xl border transition-all duration-200 ${plan.is_active ? "border-border/60 bg-card" : "border-border/30 bg-card/40 opacity-60"}`}
                style={{ animationDelay: `${i * 40 + 80}ms` }}>
                <div className="flex items-center gap-4 p-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${plan.traffic_gb === 0 ? "bg-violet-500/15 border border-violet-500/25" : "bg-blue-500/15 border border-blue-500/25"}`}>
                    {plan.traffic_gb === 0 ? <Infinity className="w-5 h-5 text-violet-400" /> : <Package className="w-5 h-5 text-blue-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground">{plan.name}</p>
                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span className="text-xs text-muted-foreground">{plan.traffic_gb > 0 ? `${plan.traffic_gb} GB` : "نامحدود"}</span>
                      <span className="text-muted-foreground/40">·</span>
                      <span className="text-xs text-muted-foreground">{plan.duration_days} روز</span>
                      {plan.limit_ip > 0 && (<><span className="text-muted-foreground/40">·</span><span className="text-xs text-muted-foreground">{plan.limit_ip} دستگاه</span></>)}
                    </div>
                    <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                      {planInbounds.length > 0
                        ? planInbounds.map(inb => (
                          <span key={inb.id} className={`inline-flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded border ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                            <Wifi className="w-2.5 h-2.5" />{inb.remark}
                          </span>
                        ))
                        : plan.inbound_ids.length > 0
                          ? <span className="text-[10px] text-muted-foreground/60">اینباند: {plan.inbound_ids.join(", ")}</span>
                          : <span className="text-[10px] text-red-400/70">بدون اینباند</span>
                      }
                    </div>
                  </div>
                  <div className="text-left shrink-0 hidden sm:block">
                    <p className="text-lg font-bold text-foreground tabular-nums">${plan.price_usdt}</p>
                    {rialPrice && <p className="text-[10px] text-muted-foreground">{rialPrice} تومان</p>}
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button onClick={() => toggleActive(plan)}
                      className={`p-2 rounded-lg transition-colors ${plan.is_active ? "text-emerald-400 hover:bg-emerald-500/10" : "text-muted-foreground hover:bg-secondary"}`}>
                      {plan.is_active ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
                    </button>
                    <button onClick={() => { if (isEditing) setEditId(null); else { setEditId(plan.id); setEditData({ ...plan }); } }}
                      className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button onClick={() => deletePlan(plan.id)}
                      className="p-2 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                {isEditing && (
                  <div className="border-t border-border/60 px-4 pb-4 pt-3 bg-secondary/10">
                    <PlanForm data={editData} setData={setEditData} title="ویرایش پلن"
                      onSave={handleEdit} onCancel={() => setEditId(null)}
                      saving={saving} inbounds={inbounds} usdtRate={usdtRate} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
