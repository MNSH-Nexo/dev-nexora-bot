"use client";
import { apiFetch } from "@/lib/api";

import { useState, useEffect, useCallback } from "react";
import {
  RefreshCw, Plus, Trash2, Tag, AlertCircle,
  ChevronDown, ChevronUp, Check, X as XIcon,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Discount {
  id: number;
  code: string;
  percent: number;
  max_uses: number | null;
  used_count: number;
  is_active: 0 | 1;
  expires_at: string | null;
  created_at: string;
}

interface DiscountsResponse {
  discounts: Discount[];
  source: string;
}

interface NewDiscountForm {
  code: string;
  percent: string;
  max_uses: string;
  expire_days: string;   // تعداد روز تا انقضا (جایگزین تاریخ)
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** نمایش روزهای باقیمانده از تاریخ انقضا */
function formatExpiry(iso: string | null): string {
  if (!iso) return "بدون انقضا";
  try {
    const diff = Math.ceil((new Date(iso).getTime() - Date.now()) / 86400000);
    if (diff < 0) return "منقضی شده";
    if (diff === 0) return "امروز منقضی می‌شود";
    return `${diff} روز مانده`;
  } catch { return "—"; }
}

/** تبدیل تعداد روز به تاریخ ISO برای ذخیره در DB */
function daysToIso(days: string): string | null {
  const n = Number(days);
  if (!days || isNaN(n) || n <= 0) return null;
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString();
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function UsageBar({ used, max }: { used: number; max: number | null }) {
  const pct = max ? Math.min(100, Math.round((used / max) * 100)) : 0;
  const color = pct >= 90 ? "bg-red-500" : pct >= 60 ? "bg-yellow-500" : "bg-green-500";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full bg-muted/30 overflow-hidden min-w-[60px]">
        <div
          className={`h-full rounded-full transition-all ${color}`}
          style={{ width: max ? `${pct}%` : "0%" }}
        />
      </div>
      <span className="text-[10px] text-muted-foreground whitespace-nowrap">
        {used} / {max ?? "نامحدود"}
      </span>
    </div>
  );
}

function ListSkeleton() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="rounded-xl bg-card/40 border border-border/30 animate-pulse h-16" />
      ))}
    </div>
  );
}

// ─── Toggle Switch ────────────────────────────────────────────────────────────

function Toggle({ active, onChange, disabled }: { active: boolean; onChange: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={onChange}
      disabled={disabled}
      aria-label={active ? "غیرفعال کردن" : "فعال کردن"}
      className={`relative inline-flex w-9 h-5 rounded-full border transition-colors duration-200 focus:outline-none disabled:cursor-not-allowed ${
        active ? "bg-green-500/80 border-green-500/50" : "bg-muted/40 border-border/60"
      }`}
    >
      <span
        className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all duration-200 ${
          active ? "right-0.5" : "left-0.5"
        }`}
      />
    </button>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function DiscountsPage() {
  const [data, setData]           = useState<DiscountsResponse | null>(null);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState<string | null>(null);
  const [showForm, setShowForm]   = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [togglingId, setTogglingId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const [form, setForm] = useState<NewDiscountForm>({
    code: "", percent: "", max_uses: "", expire_days: "",
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch("/api/discounts");
      if (!res.ok) throw new Error(`خطا: ${res.status}`);
      const json: DiscountsResponse = await res.json();
      setData(json);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطای ناشناخته");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleSubmit = useCallback(async () => {
    if (!form.code.trim() || !form.percent) {
      setFormError("کد و درصد تخفیف الزامی است.");
      return;
    }
    setFormError(null);
    setSubmitting(true);
    try {
      const body: Record<string, unknown> = {
        code: form.code.toUpperCase().trim(),
        percent: Number(form.percent),
      };
      if (form.max_uses) body.max_uses = Number(form.max_uses);
      const expiresAt = daysToIso(form.expire_days);
      if (expiresAt) body.expires_at = expiresAt;
      const res = await apiFetch("/api/discounts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`خطا: ${res.status}`);
      setForm({ code: "", percent: "", max_uses: "", expire_days: "" });
      setShowForm(false);
      await fetchData();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "خطا در ایجاد کد تخفیف");
    } finally {
      setSubmitting(false);
    }
  }, [form, fetchData]);

  const handleToggle = useCallback(async (d: Discount) => {
    setTogglingId(d.id);
    try {
      const res = await apiFetch("/api/discounts", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: d.id, is_active: d.is_active === 1 ? 0 : 1 }),
      });
      if (!res.ok) throw new Error("تغییر وضعیت ناموفق بود");
      await fetchData();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    } finally {
      setTogglingId(null);
    }
  }, [fetchData]);

  const handleDelete = useCallback(async (d: Discount) => {
    if (!confirm(`آیا از حذف کد «${d.code}» مطمئن هستید؟`)) return;
    setDeletingId(d.id);
    try {
      const res = await apiFetch(`/api/discounts?id=${d.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("حذف ناموفق بود");
      await fetchData();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    } finally {
      setDeletingId(null);
    }
  }, [fetchData]);

  const count = data?.discounts.length ?? 0;

  return (
    <div className="space-y-6 animate-in-up" dir="rtl">

      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">کدهای تخفیف</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {data && `${count} کد تخفیف`}
            {data && (
              <span className={`mr-2 ${data.source === "live" ? "text-green-400" : "text-yellow-400"}`}>
                • {data.source === "live" ? "زنده" : "ناموجود"}
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={fetchData}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-card/80 transition-colors flex items-center gap-1.5 text-muted-foreground"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
            بروزرسانی
          </button>
          <button
            onClick={() => setShowForm(v => !v)}
            className="px-3 py-1.5 rounded-lg text-xs font-medium border border-primary/40 bg-primary/10 hover:bg-primary/20 transition-colors flex items-center gap-1.5 text-primary"
          >
            {showForm ? <ChevronUp className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
            {showForm ? "بستن" : "افزودن کد"}
          </button>
        </div>
      </div>

      {/* ── Add Form ── */}
      {showForm && (
        <div className="rounded-2xl border border-border/60 bg-card p-4 animate-in-up space-y-4">
          <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Tag className="w-4 h-4 text-primary" />
            کد تخفیف جدید
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">کد تخفیف *</label>
              <input
                value={form.code}
                onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))}
                placeholder="SUMMER20"
                className="w-full px-3 py-2.5 rounded-xl bg-input border border-border text-sm focus:outline-none focus:border-primary/50 font-mono text-foreground placeholder-muted-foreground/50 uppercase"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">درصد تخفیف *</label>
              <input
                type="number"
                min={1}
                max={100}
                value={form.percent}
                onChange={e => setForm(f => ({ ...f, percent: e.target.value }))}
                placeholder="20"
                className="w-full px-3 py-2.5 rounded-xl bg-input border border-border text-sm focus:outline-none focus:border-primary/50 text-foreground placeholder-muted-foreground/50"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">حداکثر استفاده</label>
              <input
                type="number"
                min={1}
                value={form.max_uses}
                onChange={e => setForm(f => ({ ...f, max_uses: e.target.value }))}
                placeholder="نامحدود"
                className="w-full px-3 py-2.5 rounded-xl bg-input border border-border text-sm focus:outline-none focus:border-primary/50 text-foreground placeholder-muted-foreground/50"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">انقضا بعد از (روز) — خالی = بدون انقضا</label>
              <input
                type="number"
                min={1}
                value={form.expire_days}
                onChange={e => setForm(f => ({ ...f, expire_days: e.target.value }))}
                placeholder="مثلاً 30"
                className="w-full px-3 py-2.5 rounded-xl bg-input border border-border text-sm focus:outline-none focus:border-primary/50 text-foreground placeholder-muted-foreground/50"
                dir="ltr"
              />
              {form.expire_days && Number(form.expire_days) > 0 && (
                <p className="text-[10px] text-muted-foreground/70 mt-0.5">
                  منقضی می‌شود: {new Date(Date.now() + Number(form.expire_days)*86400000).toLocaleDateString("fa-IR")}
                </p>
              )}
            </div>
          </div>
          {formError && (
            <p className="text-xs text-red-400 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              {formError}
            </p>
          )}
          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              onClick={() => { setShowForm(false); setFormError(null); }}
              className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-muted/20 transition-colors text-muted-foreground flex items-center gap-1"
            >
              <XIcon className="w-3.5 h-3.5" />
              انصراف
            </button>
            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="px-4 py-1.5 rounded-lg text-xs font-medium border border-primary/40 bg-primary/20 hover:bg-primary/30 transition-colors text-primary flex items-center gap-1.5 disabled:opacity-60"
            >
              {submitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              ذخیره
            </button>
          </div>
        </div>
      )}

      {/* ── List Card ── */}
      <div className="rounded-2xl border border-border/60 bg-card p-4">
        {loading ? (
          <ListSkeleton />
        ) : error ? (
          <div className="flex flex-col items-center gap-3 py-12 text-center">
            <AlertCircle className="w-8 h-8 text-red-400" />
            <p className="text-sm text-red-400">{error}</p>
            <button onClick={fetchData} className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-card/80 transition-colors text-muted-foreground">
              تلاش مجدد
            </button>
          </div>
        ) : !data?.discounts.length ? (
          <div className="flex flex-col items-center gap-2 py-12 text-center">
            <Tag className="w-8 h-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">هیچ کد تخفیفی وجود ندارد</p>
            <p className="text-xs text-muted-foreground/60">برای افزودن اولین کد روی «افزودن کد» کلیک کنید</p>
          </div>
        ) : (
          <div className="space-y-2">
            {data.discounts.map(d => (
              <div
                key={d.id}
                className={`rounded-xl border border-border/40 bg-card/60 p-3 transition-opacity ${
                  d.is_active === 0 ? "opacity-60" : ""
                }`}
              >
                <div className="flex items-center gap-3 flex-wrap">
                  {/* Code badge */}
                  <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg border border-primary/30 bg-primary/10 text-primary">
                    {d.code}
                  </span>
                  {/* Percent badge */}
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full border border-yellow-500/30 bg-yellow-500/10 text-yellow-400">
                    {d.percent}٪ تخفیف
                  </span>
                   {/* Expiry */}
                   <span className={`text-[10px] ${d.expires_at && new Date(d.expires_at) < new Date() ? "text-red-400" : "text-muted-foreground"}`}>
                     {formatExpiry(d.expires_at)}
                   </span>
                  {/* Actions */}
                  <div className="mr-auto flex items-center gap-2">
                    <Toggle
                      active={d.is_active === 1}
                      onChange={() => handleToggle(d)}
                      disabled={togglingId === d.id}
                    />
                    <button
                      onClick={() => handleDelete(d)}
                      disabled={deletingId === d.id}
                      className="p-1.5 rounded-lg border border-red-500/20 bg-red-500/5 text-red-400 hover:bg-red-500/15 transition-colors disabled:opacity-50"
                      title="حذف"
                    >
                      {deletingId === d.id
                        ? <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        : <Trash2 className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                {/* Usage bar */}
                <div className="mt-2.5">
                  <UsageBar used={d.used_count} max={d.max_uses} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
