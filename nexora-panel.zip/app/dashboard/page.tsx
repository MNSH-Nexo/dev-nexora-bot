"use client";
import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import {
  Users, Package, Ticket,
  TrendingUp, AlertCircle,
  BarChart3, UserCheck, CircleDollarSign, CalendarClock,
  RefreshCw,
} from "lucide-react";
import StatCard from "@/components/admin/StatCard";
import RecentPayments from "@/components/admin/RecentPayments";
import ActivePlansChart from "@/components/admin/ActivePlansChart";

type Stats = {
  source: string;
  totalUsers: number; usersToday: number;
  activeSubs: number; expiringSoon: number;
  revenueTotal: number; revenueToday: number;
  pendingPayments: number; openTickets: number;
  newUsers30d: number; revenue30d: number; soldSubs30d: number; expiring30d: number;
  subActive: number; subExpired: number; subDepleted: number; subDisabled: number;
  subActivePct: number; subExpiredPct: number; subDepletedPct: number; subDisabledPct: number;
};

const EMPTY: Stats = {
  source: "loading",
  totalUsers: 0, usersToday: 0, activeSubs: 0, expiringSoon: 0,
  revenueTotal: 0, revenueToday: 0, pendingPayments: 0, openTickets: 0,
  newUsers30d: 0, revenue30d: 0, soldSubs30d: 0, expiring30d: 0,
  subActive: 0, subExpired: 0, subDepleted: 0, subDisabled: 0,
  subActivePct: 0, subExpiredPct: 0, subDepletedPct: 0, subDisabledPct: 0,
};

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats>(EMPTY);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    setLoading(true);
    try {
      const res = await apiFetch("/api/stats");
      if (res.ok) setStats(await res.json());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStats(); }, []);

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="animate-in-up flex items-center justify-between" style={{ animationDelay: "0ms" }}>
        <div>
          <h1 className="text-xl font-bold text-foreground tracking-tight">داشبورد</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            نمای کلی وضعیت ربات
            {stats.source === "unavailable" && <span className="text-yellow-400 mr-2">— دیتابیس ربات در دسترس نیست</span>}
            {stats.source === "live" && <span className="text-green-400/60 mr-2">• زنده</span>}
          </p>
        </div>
        <button onClick={fetchStats} disabled={loading}
          className="p-2 rounded-lg border border-border hover:border-primary/50 text-muted-foreground hover:text-primary transition-colors disabled:opacity-50">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Alert if pending */}
      {stats.pendingPayments > 0 && (
        <div
          className="animate-in-up flex items-center gap-3 px-4 py-3 rounded-xl border border-yellow-500/30 bg-yellow-500/8 text-yellow-300"
          style={{ animationDelay: "40ms" }}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span className="text-sm">
            <strong>{stats.pendingPayments}</strong> تراکنش در انتظار بررسی هستند
          </span>
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Users} label="کل کاربران" value={stats.totalUsers.toLocaleString("fa-IR")}
          sub={`+${stats.usersToday} امروز`} delay={80} accent="blue"
        />
        <StatCard
          icon={Package} label="اشتراک‌های فعال" value={stats.activeSubs.toLocaleString("fa-IR")}
          sub={`${stats.expiringSoon} در حال انقضا`} delay={140} accent="violet"
        />
        <StatCard
          icon={TrendingUp} label="درآمد کل (USDT)" value={`$${stats.revenueTotal.toFixed(1)}`}
          sub={`$${stats.revenueToday} امروز`} delay={200} accent="green"
        />
        <StatCard
          icon={Ticket} label="تیکت‌های باز" value={stats.openTickets.toString()}
          sub="نیاز به پاسخ" delay={260} accent="orange"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div
          className="animate-in-up lg:col-span-2 rounded-2xl border border-border/60 bg-card p-5"
          style={{ animationDelay: "380ms" }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-foreground">تراکنش‌های اخیر</h2>
            <span className="text-xs text-muted-foreground">۷ روز گذشته</span>
          </div>
          <RecentPayments />
        </div>

        <div
          className="animate-in-up rounded-2xl border border-border/60 bg-card p-5"
          style={{ animationDelay: "440ms" }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-foreground">وضعیت اشتراک‌ها</h2>
          </div>
          <ActivePlansChart
            active={stats.subActive} expired={stats.subExpired}
            depleted={stats.subDepleted} disabled={stats.subDisabled}
            activePct={stats.subActivePct} expiredPct={stats.subExpiredPct}
            depletedPct={stats.subDepletedPct} disabledPct={stats.subDisabledPct}
          />
        </div>
      </div>

      {/* Advanced Stats Row */}
      <div
        className="animate-in-up rounded-2xl border border-border/60 bg-card p-5"
        style={{ animationDelay: "500ms" }}
      >
        <div className="flex items-center gap-2 mb-5">
          <BarChart3 className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">آمار ۳۰ روز گذشته</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { icon: UserCheck,        color: "text-blue-400",    val: stats.newUsers30d.toLocaleString("fa-IR"),       label: "کاربر جدید" },
            { icon: CircleDollarSign, color: "text-emerald-400", val: `$${stats.revenue30d.toFixed(1)}`,               label: "درآمد ماه" },
            { icon: Package,          color: "text-violet-400",  val: stats.soldSubs30d.toLocaleString("fa-IR"),       label: "اشتراک فروخته‌شده" },
            { icon: CalendarClock,    color: "text-orange-400",  val: stats.expiring30d.toLocaleString("fa-IR"),       label: "در حال انقضا" },
          ].map(({ icon: Icon, color, val, label }) => (
            <div key={label} className="rounded-xl bg-background/60 border border-border/40 p-3 text-center">
              <Icon className={`w-5 h-5 ${color} mx-auto mb-2`} />
              <p className="text-xl font-bold text-foreground tabular-nums">{val}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </div>
          ))}
        </div>

        {/* Subscription status breakdown — live from DB */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { label: "فعال",      value: stats.subActive,   pct: stats.subActivePct,   color: "bg-violet-500" },
            { label: "منقضی",    value: stats.subExpired,  pct: stats.subExpiredPct,  color: "bg-slate-500" },
            { label: "تمام‌شده", value: stats.subDepleted, pct: stats.subDepletedPct, color: "bg-orange-500" },
            { label: "غیرفعال",  value: stats.subDisabled, pct: stats.subDisabledPct, color: "bg-red-500/70" },
          ].map((s) => (
            <div key={s.label} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-background/40 border border-border/30">
              <div className={`w-2 h-2 rounded-full shrink-0 ${s.color}`} />
              <span className="text-xs text-muted-foreground flex-1">{s.label}</span>
              <span className="text-xs font-semibold text-foreground tabular-nums">{s.value.toLocaleString("fa-IR")}</span>
              <span className="text-[10px] text-muted-foreground/50">{s.pct}٪</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
