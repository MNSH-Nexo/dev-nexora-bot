"use client";
import { apiFetch } from "@/lib/api";

import { useState, useEffect, useCallback } from "react";
import {
  RefreshCw, Receipt, CheckCircle, XCircle, Eye,
  ChevronLeft, ChevronRight, AlertCircle, Loader2, Clock,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type PaymentStatus = "awaiting_review" | "confirmed" | "failed" | "waiting" | "confirming" | "expired";
type PaymentMethod = "card" | "maxelpay" | "nowpayments";

interface Payment {
  id: number;
  order_id: string;
  amount_usdt: number;
  amount_rial: number;
  status: PaymentStatus;
  payment_method: PaymentMethod;
  receipt_file_id: string | null;
  receipt_type: "text" | "image" | "photo" | null;  // ربات photo ذخیره میکنه
  created_at: string;
  telegram_id: string;
  username: string | null;
  first_name: string | null;
}

interface PaymentsResponse {
  payments: Payment[];
  total: number;
  source: string;
}

type FilterTab = "all" | "awaiting_review" | "confirmed" | "failed";

// ─── Helpers ──────────────────────────────────────────────────────────────────

const LIMIT = 20;

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString("fa-IR", {
      year: "numeric", month: "short", day: "numeric",
      hour: "2-digit", minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

function methodLabel(m: PaymentMethod): string {
  if (m === "card") return "کارت";
  if (m === "maxelpay") return "MaxelPay";
  return "NOWPayments";
}

function userLabel(p: Payment): string {
  return p.first_name ?? p.username ?? p.telegram_id;
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: PaymentStatus }) {
  const map: Record<PaymentStatus, { label: string; cls: string }> = {
    awaiting_review: { label: "در انتظار", cls: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30" },
    confirmed:       { label: "تایید شد",  cls: "bg-green-500/10 text-green-400 border-green-500/30" },
    failed:          { label: "ناموفق",    cls: "bg-red-500/10 text-red-400 border-red-500/30" },
    waiting:         { label: "در صف",     cls: "bg-blue-500/10 text-blue-400 border-blue-500/30" },
    confirming:      { label: "در صف",     cls: "bg-blue-500/10 text-blue-400 border-blue-500/30" },
    expired:         { label: "منقضی",     cls: "bg-muted/20 text-muted-foreground border-border/40" },
  };
  const item = map[status] ?? { label: status, cls: "bg-muted/20 text-muted-foreground border-border/40" };
  return (
    <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${item.cls}`}>
      {item.label}
    </span>
  );
}

function TableSkeleton() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="rounded-xl bg-card/40 border border-border/30 animate-pulse h-12" />
      ))}
    </div>
  );
}

// ── TelegramReceiptPhoto — نمایش عکس رسید از Telegram ──────────
// چون file_id مستقیماً قابل نمایش در مرورگر نیست،
// از /api/payments?file_id=... استفاده میکنیم تا سرور عکس رو proxy کنه
function TelegramReceiptPhoto({ fileId }: { fileId: string }) {
  const [src, setSrc] = useState<string | null>(null);
  const [err, setErr] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setErr(false); setSrc(null);
    apiFetch(`/api/payments?file_id=${encodeURIComponent(fileId)}`)
      .then(r => r.ok ? r.blob() : Promise.reject(r.status))
      .then(blob => {
        if (!cancelled) setSrc(URL.createObjectURL(blob));
      })
      .catch(() => { if (!cancelled) setErr(true); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [fileId]);

  if (loading) return (
    <div className="rounded-xl bg-muted/20 border border-border/40 p-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
      <Loader2 className="w-4 h-4 animate-spin" />در حال بارگذاری عکس رسید...
    </div>
  );
  if (err || !src) return (
    <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/20 p-3">
      <p className="text-xs text-yellow-300">⚠️ نمایش مستقیم عکس ممکن نیست.</p>
      <p className="text-[10px] text-muted-foreground mt-1 font-mono break-all">file_id: {fileId}</p>
    </div>
  );
  return (
    <div className="rounded-xl overflow-hidden border border-border/40">
      <img src={src} alt="رسید پرداخت" className="w-full max-h-80 object-contain bg-black/20" />
    </div>
  );
}

function ReceiptModal({ payment, onClose }: { payment: Payment; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="rounded-2xl border border-border/60 bg-card p-6 max-w-md w-full mx-4 shadow-2xl animate-in-up"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground">رسید پرداخت</h3>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <XCircle className="w-5 h-5" />
          </button>
        </div>
        <div className="space-y-3">
          <div className="flex gap-2 text-xs text-muted-foreground">
            <span>شناسه سفارش:</span>
            <span className="font-mono text-foreground">{payment.order_id}</span>
          </div>
          {/* نمایش عکس رسید */}
          {payment.receipt_file_id && (payment.receipt_type === "image" || payment.receipt_type === "photo") && (
            <div className="space-y-2">
              <TelegramReceiptPhoto fileId={payment.receipt_file_id} />
            </div>
          )}
          {/* نمایش متن رسید */}
          {payment.receipt_file_id && payment.receipt_type === "text" && (
            <div className="rounded-xl bg-muted/20 border border-border/40 p-3">
              <p className="text-[10px] text-muted-foreground mb-1">متن رسید:</p>
              <p className="text-xs font-mono text-foreground break-all">{payment.receipt_file_id}</p>
            </div>
          )}
          {/* نمایش متن رسید برای مواردی که receipt_type مشخص نیست اما شبیه file_id تلگرام است */}
          {payment.receipt_file_id && !payment.receipt_type && (
            (() => {
              const isFileId = /^Ag[A-Za-z0-9_-]{20,}$/.test(payment.receipt_file_id);
              return isFileId ? (
                <div className="space-y-2">
                  <TelegramReceiptPhoto fileId={payment.receipt_file_id} />
                </div>
              ) : (
                <div className="rounded-xl bg-muted/20 border border-border/40 p-3">
                  <p className="text-xs font-mono text-foreground break-all">{payment.receipt_file_id}</p>
                </div>
              );
            })()
          )}
          {!payment.receipt_file_id && (
            <p className="text-xs text-muted-foreground">رسیدی ثبت نشده است.</p>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function PaymentsPage() {
  const [activeTab, setActiveTab]       = useState<FilterTab>("all");
  const [page, setPage]                 = useState(1);
  const [data, setData]                 = useState<PaymentsResponse | null>(null);
  const [loading, setLoading]           = useState(true);
  const [error, setError]               = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [receiptPayment, setReceiptPayment] = useState<Payment | null>(null);

  const statusParam = activeTab === "all" ? "" : activeTab;

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (statusParam) params.set("status", statusParam);
      const res = await apiFetch(`/api/payments?${params}`);
      if (!res.ok) throw new Error(`خطا: ${res.status}`);
      const json: PaymentsResponse = await res.json();
      setData(json);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطای ناشناخته");
    } finally {
      setLoading(false);
    }
  }, [page, statusParam]);

  useEffect(() => { fetchData(); }, [fetchData]);
  useEffect(() => { setPage(1); }, [activeTab]);

  const handleAction = useCallback(async (payment: Payment, action: "approve" | "reject" | "expire") => {
    setActionLoading(payment.id);
    try {
      const res = await apiFetch("/api/payments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, payment_id: payment.id }),
      });
      if (!res.ok) throw new Error("عملیات ناموفق بود");
      await fetchData();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    } finally {
      setActionLoading(null);
    }
  }, [fetchData]);

  const totalPages = data ? Math.ceil(data.total / LIMIT) : 1;

  const tabs: { key: FilterTab; label: string }[] = [
    { key: "all",            label: "همه" },
    { key: "awaiting_review", label: "در انتظار" },
    { key: "confirmed",      label: "تایید شد" },
    { key: "failed",         label: "ناموفق" },
  ];

  return (
    <div className="space-y-6 animate-in-up" dir="rtl">

      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">مدیریت پرداخت‌ها</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {data && `${data.total} پرداخت`}
            {data && (
              <span className={`mr-2 ${data.source === "live" ? "text-green-400" : "text-yellow-400"}`}>
                • {data.source === "live" ? "زنده" : "ناموجود"}
              </span>
            )}
          </p>
        </div>
        <button
          onClick={fetchData}
          disabled={loading}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-card/80 transition-colors flex items-center gap-1.5 text-muted-foreground"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          بروزرسانی
        </button>
      </div>

      {/* ── Filter Tabs ── */}
      <div className="rounded-2xl border border-border/60 bg-card p-1 flex gap-1">
        {tabs.map(t => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`flex-1 py-1.5 rounded-xl text-xs font-medium transition-colors ${
              activeTab === t.key
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Table Card ── */}
      <div className="rounded-2xl border border-border/60 bg-card p-4">
        {loading ? (
          <TableSkeleton />
        ) : error ? (
          <div className="flex flex-col items-center gap-3 py-12 text-center">
            <AlertCircle className="w-8 h-8 text-red-400" />
            <p className="text-sm text-red-400">{error}</p>
            <button
              onClick={fetchData}
              className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-card/80 transition-colors text-muted-foreground"
            >
              تلاش مجدد
            </button>
          </div>
        ) : !data?.payments.length ? (
          <div className="flex flex-col items-center gap-2 py-12 text-center">
            <Receipt className="w-8 h-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">پرداختی یافت نشد</p>
          </div>
        ) : (
          <div className="overflow-x-auto -mx-1">
            <table className="w-full text-xs min-w-[700px]">
              <thead>
                <tr className="border-b border-border/40">
                  {["شناسه", "کاربر", "روش", "مبلغ", "رسید", "وضعیت", "تاریخ", "عملیات"].map(h => (
                    <th key={h} className="text-right text-muted-foreground font-medium py-2 px-2 first:pr-0 last:pl-0">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border/20">
                {data.payments.map(p => (
                  <tr key={p.id} className="hover:bg-muted/10 transition-colors group">
                    <td className="py-2.5 px-2 first:pr-0">
                      <span className="font-mono text-[10px] text-muted-foreground">{p.order_id}</span>
                    </td>
                    <td className="py-2.5 px-2 text-foreground font-medium">{userLabel(p)}</td>
                    <td className="py-2.5 px-2 text-muted-foreground">{methodLabel(p.payment_method)}</td>
                    <td className="py-2.5 px-2 text-foreground">${p.amount_usdt}</td>
                    <td className="py-2.5 px-2">
                      {p.receipt_file_id ? (
                        <button
                          onClick={() => setReceiptPayment(p)}
                          className="p-1 rounded-lg hover:bg-primary/20 text-primary transition-colors"
                          title="مشاهده رسید"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <span className="text-muted-foreground/30">—</span>
                      )}
                    </td>
                    <td className="py-2.5 px-2"><StatusBadge status={p.status} /></td>
                    <td className="py-2.5 px-2 text-muted-foreground whitespace-nowrap">{formatDate(p.created_at)}</td>
                    <td className="py-2.5 px-2 last:pl-0">
                      {p.status === "awaiting_review" && p.payment_method === "card" ? (
                        <div className="flex items-center gap-1 flex-wrap">
                          <button onClick={() => handleAction(p, "approve")} disabled={actionLoading === p.id}
                            className="px-2 py-1 rounded-lg text-[10px] font-medium border border-green-500/30 bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors disabled:opacity-50 flex items-center gap-1">
                            {actionLoading === p.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle className="w-3 h-3" />}
                            تایید
                          </button>
                          <button onClick={() => handleAction(p, "reject")} disabled={actionLoading === p.id}
                            className="px-2 py-1 rounded-lg text-[10px] font-medium border border-red-500/30 bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors disabled:opacity-50 flex items-center gap-1">
                            {actionLoading === p.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <XCircle className="w-3 h-3" />}
                            رد
                          </button>
                        </div>
                      ) : (p.status === "waiting" || p.status === "confirming") ? (
                        // تراکنش‌های کریپتو در صف — قابل منقضی کردن
                        <button onClick={() => { if(confirm("این تراکنش منقضی شود؟")) handleAction(p, "expire"); }}
                          disabled={actionLoading === p.id}
                          className="px-2 py-1 rounded-lg text-[10px] font-medium border border-muted/40 bg-muted/20 text-muted-foreground hover:text-orange-400 hover:border-orange-500/30 hover:bg-orange-500/10 transition-colors disabled:opacity-50 flex items-center gap-1">
                          {actionLoading === p.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Clock className="w-3 h-3" />}
                          منقضی
                        </button>
                      ) : (
                        <span className="text-muted-foreground/30 text-[10px]">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* ── Pagination ── */}
        {!loading && !error && totalPages > 1 && (
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/40">
            <span className="text-xs text-muted-foreground">
              صفحه {page} از {totalPages}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(prev => Math.max(1, prev - 1))}
                disabled={page === 1}
                className="p-1.5 rounded-lg border border-border/60 bg-card hover:bg-muted/20 disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
              {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                const p = Math.max(1, Math.min(page - 2 + i, totalPages - 4 + i));
                return (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={`w-7 h-7 rounded-lg text-xs font-medium border transition-colors ${
                      p === page
                        ? "border-primary/50 bg-primary/20 text-primary"
                        : "border-border/40 text-muted-foreground hover:text-foreground hover:bg-muted/20"
                    }`}
                  >
                    {p}
                  </button>
                );
              })}
              <button
                onClick={() => setPage(prev => Math.min(totalPages, prev + 1))}
                disabled={page === totalPages}
                className="p-1.5 rounded-lg border border-border/60 bg-card hover:bg-muted/20 disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ── Receipt Modal ── */}
      {receiptPayment && (
        <ReceiptModal payment={receiptPayment} onClose={() => setReceiptPayment(null)} />
      )}
    </div>
  );
}
