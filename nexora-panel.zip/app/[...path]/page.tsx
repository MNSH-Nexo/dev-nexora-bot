// Catch-all: middleware قبلاً مسیرهای غیرمجاز را بلاک کرده
// این صفحه فقط برای مسیرهای ناشناخته داخل webpath اجرا می‌شود
import { notFound } from "next/navigation";
export default function CatchAll() {
  notFound();
}
