import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth, getSetting, setSetting } from "@/lib/botdb";
import { xuiGetInbounds, getPanelStatus } from "@/lib/xui";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

// ── GET /api/inbounds ────────────────────────────────────────
export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  // Try to get from 3X-UI panel
  const { configured } = getPanelStatus();
  if (!configured) {
    return NextResponse.json({ inbounds: [], source: "panel_not_configured" });
  }

  const xuiInbounds = await xuiGetInbounds();

  const db = getBotDb(true);
  const enabledStr = db ? getSetting(db, "enabled_inbound_ids", "") : "";
  if (db) db.close();

  const enabledIds = enabledStr
    ? enabledStr.split(",").filter(Boolean).map(Number)
    : [];

  if (xuiInbounds) {
    // Map XUI inbound format to our format
    const inbounds = xuiInbounds.map((inb: Record<string, unknown>) => ({
      id: inb.id,
      remark: inb.remark ?? `Inbound #${inb.id}`,
      protocol: inb.protocol ?? "unknown",
      port: inb.port ?? 0,
      enable: inb.enable !== false,
      clients: Array.isArray(inb.clientStats) ? inb.clientStats.length : 0,
      up: inb.up ?? 0,
      down: inb.down ?? 0,
      panel_enabled: enabledIds.includes(Number(inb.id)),
    }));
    return NextResponse.json({ inbounds, source: "live" });
  }

  // Fallback: return empty with source flag
  return NextResponse.json({ inbounds: [], source: "panel_unavailable" });
}

// ── POST /api/inbounds/toggle ─── toggle panel-enabled status
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { inbound_id } = await req.json().catch(() => ({}));
  if (!inbound_id) return NextResponse.json({ error: "inbound_id required" }, { status: 400 });

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    const current = getSetting(db, "enabled_inbound_ids", "");
    const ids = current ? current.split(",").filter(Boolean).map(Number) : [];
    const idx = ids.indexOf(Number(inbound_id));
    let enabled: boolean;
    if (idx >= 0) {
      ids.splice(idx, 1);
      enabled = false;
    } else {
      ids.push(Number(inbound_id));
      enabled = true;
    }
    setSetting(db, "enabled_inbound_ids", ids.join(","));
    db.close();
    return NextResponse.json({ ok: true, enabled });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
