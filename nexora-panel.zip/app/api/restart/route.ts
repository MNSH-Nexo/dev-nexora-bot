/**
 * POST /api/restart
 * body: { target: "bot" | "panel" | "both" }
 *
 * ربات با docker compose restart اجرا می‌شود.
 * وب‌پنل با supervisorctl یا pm2 ری‌استارت می‌شود.
 */
import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/botdb";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);
function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

async function tryCommand(cmd: string): Promise<{ ok: boolean; out: string }> {
  try {
    const { stdout, stderr } = await execAsync(cmd, { timeout: 15000 });
    return { ok: true, out: (stdout + stderr).trim() };
  } catch (e: unknown) {
    const err = e as { message?: string; stderr?: string };
    return { ok: false, out: err?.stderr ?? err?.message ?? String(e) };
  }
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { target } = await req.json().catch(() => ({ target: "bot" }));
  const results: Array<{ label: string; ok: boolean; out: string }> = [];

  // ── ری‌استارت ربات ──────────────────────────────────────
  if (target === "bot" || target === "both") {
    // اول Docker بررسی می‌کند، بعد systemctl، بعد supervisorctl
    const candidates = [
      { label: "docker compose (nexora)", cmd: "cd /opt/nexora-bot && docker compose restart bot 2>&1 | tail -5" },
      { label: "systemctl nexora-bot",    cmd: "systemctl restart nexora-bot 2>&1 | tail -5" },
      { label: "supervisorctl nexora-bot", cmd: "supervisorctl restart nexora-bot 2>&1 | tail -5" },
    ];

    let restarted = false;
    for (const c of candidates) {
      const r = await tryCommand(c.cmd);
      if (r.ok) {
        results.push({ label: c.label, ok: true, out: r.out || "ری‌استارت با موفقیت انجام شد" });
        restarted = true;
        break;
      }
    }
    if (!restarted) {
      results.push({ label: "ربات", ok: false, out: "روش ری‌استارت یافت نشد — لطفاً دستی ری‌استارت کنید" });
    }
  }

  // ── ری‌استارت وب‌پنل ────────────────────────────────────
  if (target === "panel" || target === "both") {
    // ترتیب اولویت:
    // 1. systemctl nexora-panel (نصب پروداکشن با install.sh)
    // 2. pm2 nexora-panel (اگر pm2 نصب باشد)
    // 3. supervisorctl nexora-panel (اگر supervisord باشد)
    // 4. فرستادن پاسخ و سپس process.exit(0) — سیستم مدیریت پروسه (systemd/supervisord) مجدداً راه‌اندازی می‌کند
    const candidates = [
      { label: "systemctl nexora-panel",   cmd: "systemctl restart nexora-panel 2>&1 | tail -5" },
      { label: "pm2 nexora-panel",         cmd: "pm2 restart nexora-panel --no-autorestart 2>&1 | tail -5 || pm2 restart nexora-panel 2>&1 | tail -5" },
      { label: "supervisorctl nexora-panel", cmd: "supervisorctl restart nexora-panel 2>&1 | tail -5" },
      // مسیرهای جایگزین pm2
      { label: "pm2 (مسیر کامل)",          cmd: "/usr/local/bin/pm2 restart nexora-panel 2>&1 | tail -5 || /usr/bin/pm2 restart nexora-panel 2>&1 | tail -5" },
      { label: "npm start (pkill+start)",  cmd: "pkill -f 'next start' 2>&1; sleep 1; echo 'process restarting'" },
    ];

    let restarted = false;
    for (const c of candidates) {
      // برای pkill، همیشه موفق تلقی می‌شود
      if (c.label.includes("pkill")) {
        await tryCommand(c.cmd);
        results.push({ label: c.label, ok: true, out: "سرویس در حال راه‌اندازی مجدد است..." });
        restarted = true;
        break;
      }
      const r = await tryCommand(c.cmd);
      if (r.ok) {
        results.push({ label: c.label, ok: true, out: r.out || "وب‌پنل با موفقیت ری‌استارت شد" });
        restarted = true;
        break;
      }
    }

    if (!restarted) {
      // آخرین راه حل: process.exit باعث می‌شود سیستم مدیریت پروسه (systemd/supervisord) مجدداً راه‌اندازی کند
      results.push({ label: "self-restart", ok: true, out: "وب‌پنل در حال ری‌استارت است — لحظاتی دیگر در دسترس خواهد بود" });
      // پاسخ را ارسال می‌کنیم و سپس خارج می‌شویم
      const response = NextResponse.json({ ok: true, results, selfRestart: true });
      setTimeout(() => {
        process.exit(0);
      }, 500);
      return response;
    }
  }

  const allOk = results.every(r => r.ok);
  return NextResponse.json({ ok: allOk, results });
}
