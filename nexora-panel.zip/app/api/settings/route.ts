import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth, getSetting, setSetting } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

// Keys that live in admin_settings table of bot DB
// ⚠️ این key ها باید دقیقاً با services/card_payment.py و services/payment_methods.py ربات مطابقت داشته باشن
const SETTING_KEYS = [
  "card_number",               // ربات: CARD_NUMBER_KEY
  "card_holder",               // ربات: CARD_HOLDER_KEY
  "usdt_to_toman_rate",        // ربات: USDT_TO_TOMAN_KEY (قبلاً اشتباه usd_to_irt_rate بود)
  "payment_crypto_enabled",    // ربات: CRYPTO_KEY (قبلاً اشتباه crypto_enabled بود)
  "payment_card_enabled",      // ربات: CARD_KEY (قبلاً اشتباه card_enabled بود)
  "crypto_gateway",            // ربات: CRYPTO_GATEWAY_KEY — maxelpay | nowpayments
  "test_sub_enabled",          // ربات: test_sub_enabled
  "test_sub_traffic_gb",       // ربات: test_sub_traffic_gb
  "test_sub_duration_days",    // ربات: test_sub_duration_days (قبلاً اشتباه test_sub_days بود)
];

// ── GET /api/settings ────────────────────────────────────────
export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const db = getBotDb(true);
  if (!db) {
    // Return env defaults when DB is not available
    return NextResponse.json({
      source: "env",
      card_number: "",
      card_holder: "",
      usdt_to_toman_rate: "90000",
      payment_crypto_enabled: "1",
      payment_card_enabled: "1",
      crypto_gateway: "maxelpay",
      test_sub_enabled: "1",
      test_sub_traffic_gb: "1",
      test_sub_duration_days: "1",
    });
  }

  try {
    const result: Record<string, string> = { source: "live" };
    for (const key of SETTING_KEYS) {
      result[key] = getSetting(db, key, "");
    }
    db.close();
    return NextResponse.json(result);
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

// ── POST /api/settings ───────────────────────────────────────
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    for (const key of SETTING_KEYS) {
      if (key in body) {
        setSetting(db, key, String(body[key]));
      }
    }
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
