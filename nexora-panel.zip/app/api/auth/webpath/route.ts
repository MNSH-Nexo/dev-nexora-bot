import { NextResponse } from "next/server";

// Returns the configured WEB_PANEL_PATH so the client can build correct redirect URLs
export async function GET() {
  const webPath = (process.env.WEB_PANEL_PATH ?? "").trim().replace(/\/$/, "");
  return NextResponse.json({ webPath: webPath || "" });
}
