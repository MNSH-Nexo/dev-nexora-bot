import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const page   = Math.max(1, Number(searchParams.get("page") ?? 1));
  const limit  = Math.min(50, Number(searchParams.get("limit") ?? 20));
  const offset = (page - 1) * limit;
  const search = searchParams.get("search") ?? "";
  const userId = searchParams.get("user_id");   // fetch subscriptions for a specific user

  const db = getBotDb(true);
  if (!db) return NextResponse.json({ users: [], total: 0, source: "unavailable" });

  try {
    // Subscriptions for one user
    if (userId) {
      const subs = db.prepare(`
        SELECT id, email, client_uuid, traffic_limit_gb, used_traffic_bytes,
               expiry_date, limit_ip, status, inbound_id, created_at
        FROM subscriptions WHERE user_id = ?
        ORDER BY created_at DESC
      `).all(Number(userId));
      db.close();
      return NextResponse.json({ subscriptions: subs, source: "live" });
    }

    // Users list with optional search
    // حذف @ از ابتدا برای جستجوی یوزرنیم — جستجو با @ هم باید کار کند
    const cleanSearch = search.startsWith("@") ? search.slice(1) : search;
    const where = cleanSearch
      ? "WHERE u.username LIKE ? OR u.first_name LIKE ? OR CAST(u.telegram_id AS TEXT) LIKE ?"
      : "";
    const sp = cleanSearch ? [`%${cleanSearch}%`, `%${cleanSearch}%`, `%${cleanSearch}%`] : [];

    const total = (db.prepare(`SELECT COUNT(*) as c FROM users u ${where}`).get(...sp) as { c: number }).c;
    const users = db.prepare(`
      SELECT u.id, u.telegram_id, u.username, u.first_name, u.is_admin, u.created_at,
             COUNT(DISTINCT s.id) as sub_count,
             MAX(CASE WHEN s.status='active' THEN s.expiry_date END) as active_until
      FROM users u LEFT JOIN subscriptions s ON s.user_id = u.id
      ${where}
      GROUP BY u.id ORDER BY u.created_at DESC LIMIT ? OFFSET ?
    `).all(...sp, limit, offset) as User[];
    db.close();
    return NextResponse.json({ users, total, page, limit, source: "live" });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}

// POST: مدیریت اشتراک — دستور به ربات از طریق pending_actions
// ربات با 3X-UI هماهنگ می‌کنه + DB رو آپدیت می‌کنه
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const { action, sub_id, field, value } = body;
  if (!sub_id || !action) return NextResponse.json({ error: "sub_id and action required" }, { status: 400 });

  // ── حذف دائمی از DB — مستقیم بدون pending_action ──────────────
  if (action === "permanent_delete") {
    // getBotDb(false) = read-write
    const db = getBotDb(false);
    if (!db) {
      return NextResponse.json(
        { error: "دیتابیس ربات پیدا نشد. مسیر BOT_DB_PATH را در .env.local بررسی کنید." },
        { status: 503 }
      );
    }
    try {
      // WAL mode: چند connection همزمان می‌توانند بنویسند
      try { db.pragma("journal_mode = WAL"); } catch { /* ignore */ }
      try { db.pragma("busy_timeout = 5000"); } catch { /* ignore */ }

      const info = db.prepare("DELETE FROM subscriptions WHERE id = ?").run(Number(sub_id));
      db.close();

      if (info.changes === 0) {
        // رکورد از قبل حذف شده یا id اشتباه است
        return NextResponse.json({ ok: true, already_deleted: true });
      }
      return NextResponse.json({ ok: true });
    } catch (e) {
      try { db.close(); } catch { /* */ }
      return NextResponse.json({ error: `خطا در حذف: ${String(e)}` }, { status: 500 });
    }
  }

  // ── ویرایش اشتراک — از طریق pending_action به ربات ────────────
  if (action === "edit_sub") {
    if (!field || value === undefined || value === null)
      return NextResponse.json({ error: "field and value required" }, { status: 400 });
    const db = getBotDb(false);
    if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });
    try {
      db.prepare(`CREATE TABLE IF NOT EXISTS pending_actions (
        id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL,
        payload TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT (datetime('now'))
      )`).run();
      db.prepare("INSERT INTO pending_actions (type, payload, created_at) VALUES (?, ?, datetime('now'))")
        .run("sub_edit", JSON.stringify({ sub_id: Number(sub_id), field: String(field), value: String(value) }));
      db.close();
      return NextResponse.json({ ok: true });
    } catch (e) { try { db.close(); } catch { /* */ } return NextResponse.json({ error: String(e) }, { status: 500 }); }
  }

  const typeMap: Record<string, string> = {
    reset_traffic: "sub_reset",
    toggle:        "sub_toggle",
    delete:        "sub_delete",
  };
  const pendingType = typeMap[action as string];
  if (!pendingType) return NextResponse.json({ error: "unknown action" }, { status: 400 });

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    db.prepare(`CREATE TABLE IF NOT EXISTS pending_actions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL,
      payload TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`).run();
    db.prepare("INSERT INTO pending_actions (type, payload, created_at) VALUES (?, ?, datetime('now'))")
      .run(pendingType, JSON.stringify({ sub_id: Number(sub_id) }));
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) { try { db.close(); } catch { /* */ } return NextResponse.json({ error: String(e) }, { status: 500 }); }
}
