import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

// ── helper: ارسال پیام تلگرام ────────────────────────────────
async function tgSend(chatId: number | string, text: string): Promise<boolean> {
  const token = process.env.BOT_TOKEN ?? "";
  if (!token || !chatId) return false;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" }),
    });
    const d = await res.json() as { ok: boolean };
    return d.ok;
  } catch { return false; }
}

// ── GET /api/tickets ────────────────────────────────────────
export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const db = getBotDb(true);
  if (!db) return NextResponse.json({ tickets: [], source: "unavailable" });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      const ticket = db.prepare(
        `SELECT t.id, t.subject, t.status, t.created_at, t.updated_at,
                u.telegram_id, u.username, u.first_name
         FROM tickets t LEFT JOIN users u ON u.id = t.user_id
         WHERE t.id = ?`
      ).get(Number(id)) as Record<string, unknown> | undefined;

      if (!ticket) { db.close(); return NextResponse.json({ error: "not found" }, { status: 404 }); }

      const messages = db.prepare(
        `SELECT m.id, m.body, m.is_admin_reply, m.created_at,
                u.telegram_id, u.username, u.first_name
         FROM ticket_messages m LEFT JOIN users u ON u.id = m.sender_id
         WHERE m.ticket_id = ? ORDER BY m.created_at ASC`
      ).all(Number(id));

      db.close();
      return NextResponse.json({ ticket, messages, source: "live" });
    }

    const status = searchParams.get("status") ?? null;
    const whereClause = status ? "WHERE t.status = ?" : "";
    const params = status ? [status] : [];

    const tickets = db.prepare(
      `SELECT t.id, t.subject, t.status, t.created_at, t.updated_at,
              u.telegram_id, u.username, u.first_name,
              (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = t.id) as msg_count
       FROM tickets t LEFT JOIN users u ON u.id = t.user_id
       ${whereClause}
       ORDER BY t.updated_at DESC LIMIT 50`
    ).all(...params);

    db.close();
    return NextResponse.json({ tickets, source: "live" });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}

// ── POST /api/tickets ── دستور به ربات از طریق pending_actions
// ربات در DB ذخیره می‌کنه + به کاربر تلگرام notify می‌کنه
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({})) as Record<string, unknown>;
  const { action, ticket_id, message } = body;

  if (!ticket_id) return NextResponse.json({ error: "ticket_id required" }, { status: 400 });
  if (action === "reply" && !message) return NextResponse.json({ error: "message required" }, { status: 400 });

  const typeMap: Record<string, string> = {
    reply:  "ticket_reply",
    close:  "ticket_close",
    reopen: "ticket_reopen",
  };
  const pendingType = typeMap[action as string];
  if (!pendingType) return NextResponse.json({ error: "unknown action" }, { status: 400 });

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    db.prepare(`CREATE TABLE IF NOT EXISTS pending_actions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL,
      payload TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`).run();

    const payload: Record<string, unknown> = { ticket_id: Number(ticket_id) };
    if (action === "reply") payload.message = (message as string).trim();

    db.prepare("INSERT INTO pending_actions (type, payload, created_at) VALUES (?, ?, datetime('now'))")
      .run(pendingType, JSON.stringify(payload));

    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) {
    try { db.close(); } catch { /* */ }
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
