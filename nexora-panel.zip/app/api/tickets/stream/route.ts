/**
 * GET /api/tickets/stream?ticket_id=N
 *
 * Server-Sent Events — هر 2 ثانیه DB را چک می‌کند.
 * اگر پیام یا تیکت جدیدی آمده، event می‌فرستد.
 * کلاینت با EventSource وصل می‌شود و بدون refresh صفحه، پیام‌ها live می‌رسند.
 *
 * Events:
 *   ping            — هر 2ث برای alive نگه داشتن اتصال
 *   messages        — data: JSON آرایه پیام‌های تیکت (وقتی تغییر کرد)
 *   ticket_status   — data: JSON وضعیت تیکت (وقتی status تغییر کرد)
 *   tickets_list    — data: JSON لیست همه تیکت‌ها (بدون ticket_id — برای صفحه اصلی)
 */

import { NextRequest } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const POLL_MS   = 2000;   // فاصله polling
const MAX_MS    = 55000;  // حداکثر مدت اتصال (کمی کمتر از timeout معمول سرورها)

function getMessages(db: import("better-sqlite3").Database, ticketId: number) {
  return db.prepare(
    `SELECT m.id, m.body, m.is_admin_reply, m.created_at,
            u.telegram_id, u.username, u.first_name
     FROM ticket_messages m
     LEFT JOIN users u ON u.id = m.sender_id
     WHERE m.ticket_id = ?
     ORDER BY m.created_at ASC`
  ).all(ticketId);
}

function getTicketStatus(db: import("better-sqlite3").Database, ticketId: number) {
  return db.prepare(
    `SELECT id, status, updated_at FROM tickets WHERE id = ?`
  ).get(ticketId) as { id: number; status: string; updated_at: string } | undefined;
}

function getTicketsList(db: import("better-sqlite3").Database) {
  return db.prepare(
    `SELECT t.id, t.subject, t.status, t.created_at, t.updated_at,
            u.telegram_id, u.username, u.first_name,
            (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = t.id) as msg_count
     FROM tickets t LEFT JOIN users u ON u.id = t.user_id
     ORDER BY t.updated_at DESC LIMIT 50`
  ).all();
}

export async function GET(req: NextRequest) {
  // auth با cookie
  if (!requireAuth(req as unknown as Request)) {
    return new Response("Unauthorized", { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const ticketId = searchParams.get("ticket_id")
    ? Number(searchParams.get("ticket_id"))
    : null;

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      const send = (event: string, data: unknown) => {
        try {
          controller.enqueue(
            encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)
          );
        } catch { /* connection closed */ }
      };

      const startTime = Date.now();

      // وضعیت قبلی برای مقایسه تغییرات
      let lastMsgId   = -1;
      let lastStatus  = "";
      let lastUpdated = "";  // updated_at آخرین تیکت در لیست

      // اولین بار داده بفرست
      try {
        const db = getBotDb(true);
        if (db) {
          if (ticketId) {
            const msgs = getMessages(db, ticketId);
            const ticket = getTicketStatus(db, ticketId);
            if (msgs.length > 0) {
              lastMsgId = (msgs[msgs.length - 1] as { id: number }).id;
            }
            if (ticket) lastStatus = ticket.status;
            send("messages", msgs);
            send("ticket_status", ticket ?? null);
          } else {
            const list = getTicketsList(db);
            if (list.length > 0) {
              lastUpdated = (list[0] as { updated_at: string }).updated_at;
            }
            send("tickets_list", list);
          }
          db.close();
        }
      } catch { /* ignore initial error */ }

      // polling loop
      while (Date.now() - startTime < MAX_MS) {
        await new Promise(r => setTimeout(r, POLL_MS));

        try {
          // ping برای alive نگه داشتن اتصال
          controller.enqueue(encoder.encode(`event: ping\ndata: {}\n\n`));
        } catch { break; /* client disconnected */ }

        try {
          const db = getBotDb(true);
          if (!db) continue;

          if (ticketId) {
            // بررسی پیام‌های جدید
            const msgs = getMessages(db, ticketId);
            const newLastId = msgs.length > 0
              ? (msgs[msgs.length - 1] as { id: number }).id
              : -1;

            if (newLastId !== lastMsgId) {
              lastMsgId = newLastId;
              send("messages", msgs);
            }

            // بررسی تغییر status
            const ticket = getTicketStatus(db, ticketId);
            if (ticket && ticket.status !== lastStatus) {
              lastStatus = ticket.status;
              send("ticket_status", ticket);
            }
          } else {
            // لیست تیکت‌ها — بررسی تغییر
            const list = getTicketsList(db);
            const newUpdated = list.length > 0
              ? (list[0] as { updated_at: string }).updated_at
              : "";
            if (newUpdated !== lastUpdated) {
              lastUpdated = newUpdated;
              send("tickets_list", list);
            }
          }

          db.close();
        } catch { /* DB error — skip this round */ }
      }

      // بعد از MAX_MS اتصال را ببند تا کلاینت reconnect کند
      try {
        send("reconnect", { reason: "timeout" });
        controller.close();
      } catch { /* already closed */ }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type":  "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      "Connection":    "keep-alive",
      "X-Accel-Buffering": "no",  // nginx buffering را خاموش می‌کند
    },
  });
}
