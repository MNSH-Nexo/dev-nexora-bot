import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const db = getBotDb(true);
  if (!db) return NextResponse.json({ discounts: [], source: "unavailable" });
  try {
    const discounts = db.prepare(
      "SELECT id, code, percent, max_uses, used_count, is_active, expires_at, created_at FROM discount_codes ORDER BY created_at DESC"
    ).all();
    db.close();
    return NextResponse.json({ discounts, source: "live" });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const { code, percent, max_uses, expires_at } = body;
  if (!code || !percent) return NextResponse.json({ error: "code and percent required" }, { status: 400 });
  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });
  try {
    const now = new Date().toISOString();
    const result = db.prepare(
      "INSERT INTO discount_codes (code, percent, max_uses, used_count, is_active, expires_at, created_at) VALUES (?,?,?,0,1,?,?)"
    ).run(String(code).toUpperCase(), Number(percent), max_uses ?? null, expires_at ?? null, now);
    db.close();
    return NextResponse.json({ id: result.lastInsertRowid, ok: true });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}

export async function PUT(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const { id, ...fields } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  if (fields.is_active !== undefined) fields.is_active = fields.is_active ? 1 : 0;
  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });
  try {
    const cols = Object.keys(fields).map(k => `${k} = ?`).join(", ");
    db.prepare(`UPDATE discount_codes SET ${cols} WHERE id = ?`).run(...Object.values(fields), id);
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}

export async function DELETE(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });
  try {
    db.prepare("DELETE FROM discount_codes WHERE id = ?").run(Number(id));
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}
