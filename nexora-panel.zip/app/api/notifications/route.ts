/**
 * GET /api/notifications
 * آمار فوری: پرداخت‌های در انتظار + تیکت‌های باز + اشتراک‌های در حال انقضا
 */
import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const db = getBotDb(true);
  if (!db) {
    return NextResponse.json({
      source: "unavailable",
      pendingPayments: 0,
      openTickets: 0,
      expiringSoon: 0,
      total: 0,
      items: [],
    });
  }

  try {
    const now     = new Date().toISOString();
    const in7days = new Date(Date.now() + 7 * 86400000).toISOString();

    const q = <T>(sql: string, ...p: unknown[]) =>
      (db.prepare(sql).get(...p) as T);

    const pendingPayments = q<{ c: number }>(
      "SELECT COUNT(*) as c FROM payments WHERE status IN ('awaiting_review','waiting','confirming')"
    ).c;

    const openTickets = q<{ c: number }>(
      "SELECT COUNT(*) as c FROM tickets WHERE status IN ('open','in_progress')"
    ).c;

    const expiringSoon = q<{ c: number }>(
      "SELECT COUNT(*) as c FROM subscriptions WHERE status='active' AND expiry_date BETWEEN ? AND ?",
      now, in7days
    ).c;

    // آخرین پرداخت‌های در انتظار
    const recentPending = db.prepare(`
      SELECT p.id, p.amount_usdt, p.payment_method, p.created_at,
             u.first_name, u.username
      FROM payments p LEFT JOIN users u ON u.id = p.user_id
      WHERE p.status IN ('awaiting_review','waiting','confirming')
      ORDER BY p.created_at DESC LIMIT 5
    `).all() as Array<Record<string, unknown>>;

    // تیکت‌های باز اخیر
    const recentTickets = db.prepare(`
      SELECT t.id, t.subject, t.status, t.created_at,
             u.first_name, u.username
      FROM tickets t LEFT JOIN users u ON u.id = t.user_id
      WHERE t.status IN ('open','in_progress')
      ORDER BY t.updated_at DESC LIMIT 5
    `).all() as Array<Record<string, unknown>>;

    db.close();

    const items: Array<{ type: string; label: string; time: string; link: string }> = [
      ...recentPending.map(p => ({
        type: "payment",
        label: `پرداخت ${(p.payment_method as string) === "card" ? "کارت" : "کریپتو"} — ${p.first_name ?? p.username ?? "کاربر"} — $${p.amount_usdt}`,
        time: p.created_at as string,
        link: "/dashboard/payments",
      })),
      ...recentTickets.map(t => ({
        type: "ticket",
        label: `تیکت: ${(t.subject as string)?.slice(0, 40) ?? "بدون موضوع"}`,
        time: t.created_at as string,
        link: "/dashboard/tickets",
      })),
    ].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()).slice(0, 8);

    const total = pendingPayments + openTickets;

    return NextResponse.json({
      source: "live",
      pendingPayments,
      openTickets,
      expiringSoon,
      total,
      items,
    });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
