/**
 * POST /api/broadcast
 * ارسال پیام دسته‌جمعی به همه کاربران از طریق ربات
 *
 * حالت‌ها:
 *   1. JSON  { message, target: "all_users" }         → پیام متنی
 *   2. FormData { photo: File, message?, target }      → عکس + متن (caption)
 *   3. JSON  { message, target: "admins" }             → مستقیم از Telegram Bot API
 *
 * برای target="all_users" یک ردیف bot_broadcast در pending_actions می‌نویسیم.
 * ربات آن را می‌خواند و با throttle (30/s) به همه کاربران می‌فرستد.
 */
import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

async function tgSendMessage(token: string, chatId: string, text: string): Promise<boolean> {
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true }),
    });
    return ((await res.json()) as { ok: boolean }).ok === true;
  } catch { return false; }
}

/**
 * عکس را به تلگرام آپلود می‌کند و file_id برمی‌گرداند.
 * از sendPhoto با chat_id اولین ادمین استفاده می‌کند.
 */
async function uploadPhotoToTelegram(token: string, adminId: string, photoBytes: Uint8Array, filename: string): Promise<string | null> {
  try {
    const form = new FormData();
    form.append("chat_id", adminId);
    form.append("photo", new Blob([photoBytes]), filename);
    const res = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
      method: "POST",
      body: form,
    });
    const data = await res.json() as { ok: boolean; result?: { photo?: Array<{ file_id: string }> } };
    if (data.ok && data.result?.photo?.length) {
      // بزرگ‌ترین سایز (آخرین آیتم) را برمی‌گردانیم
      const photos = data.result.photo;
      return photos[photos.length - 1].file_id;
    }
    return null;
  } catch { return null; }
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const contentType = req.headers.get("content-type") ?? "";
  let message = "";
  let target = "all_users";
  let photoFileId: string | null = null;

  if (contentType.includes("multipart/form-data")) {
    const form = await req.formData().catch(() => null);
    if (!form) return NextResponse.json({ error: "invalid form data" }, { status: 400 });
    message = String(form.get("message") ?? form.get("caption") ?? "").trim();
    target  = String(form.get("target") ?? "all_users");

    // فایل عکس موجود است — آپلود به تلگرام برای گرفتن file_id
    const photoFile = form.get("photo");
    if (photoFile && photoFile instanceof Blob) {
      const botToken  = process.env.BOT_TOKEN ?? "";
      const adminIds  = (process.env.ADMIN_IDS ?? "").split(",").map(s => s.trim()).filter(Boolean);
      if (!botToken || !adminIds.length) {
        return NextResponse.json({ error: "BOT_TOKEN یا ADMIN_IDS تنظیم نشده" }, { status: 503 });
      }
      const photoBytes = new Uint8Array(await photoFile.arrayBuffer());
      const fname = (photoFile as File).name ?? "broadcast.jpg";
      photoFileId = await uploadPhotoToTelegram(botToken, adminIds[0], photoBytes, fname);
      if (!photoFileId) {
        return NextResponse.json({ error: "آپلود عکس به تلگرام ناموفق بود" }, { status: 502 });
      }
    } else {
      // photo_file_id از قبل داده شده (fallback)
      photoFileId = String(form.get("photo_file_id") ?? "").trim() || null;
    }
  } else {
    const body = await req.json().catch(() => ({})) as Record<string, unknown>;
    message     = String(body.message ?? "").trim();
    target      = String(body.target ?? "all_users");
    photoFileId = String(body.photo_file_id ?? "").trim() || null;
  }

  if (!message && !photoFileId) {
    return NextResponse.json({ error: "message یا photo_file_id الزامی است" }, { status: 400 });
  }

  // ── target=admins: مستقیم از Telegram Bot API ──────────────
  if (target === "admins") {
    const botToken = process.env.BOT_TOKEN ?? "";
    const adminIds = (process.env.ADMIN_IDS ?? "").split(",").map(s => s.trim()).filter(Boolean);
    if (!botToken) return NextResponse.json({ error: "BOT_TOKEN not configured" }, { status: 503 });
    if (!adminIds.length) return NextResponse.json({ error: "ADMIN_IDS not configured" }, { status: 503 });
    const results = await Promise.all(adminIds.map(id => tgSendMessage(botToken, id, message)));
    const sent = results.filter(Boolean).length;
    return NextResponse.json({ ok: true, sent, total: adminIds.length, mode: "admins_direct" });
  }

  // ── target=all_users: از طریق pending_actions به ربات ─────
  // ربات هر ۱۵ ثانیه pending_actions را بررسی می‌کند
  // و با broadcast handler پیام را به همه کاربران می‌فرستد
  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable — ربات در دسترس نیست" }, { status: 503 });

  try {
    db.prepare(`
      CREATE TABLE IF NOT EXISTS pending_actions (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        type       TEXT    NOT NULL,
        payload    TEXT    NOT NULL DEFAULT '{}',
        created_at TEXT    NOT NULL DEFAULT (datetime('now'))
      )
    `).run();

    const payload: Record<string, unknown> = { message };
    if (photoFileId) payload.photo_file_id = photoFileId;

    db.prepare(
      "INSERT INTO pending_actions (type, payload, created_at) VALUES ('bot_broadcast', ?, datetime('now'))"
    ).run(JSON.stringify(payload));

    // تعداد کاربران را برای اطلاع رسانی برمی‌گردانیم
    let userCount = 0;
    try {
      const row = db.prepare("SELECT COUNT(*) as c FROM users").get() as { c: number } | undefined;
      userCount = row?.c ?? 0;
    } catch { /* ignore */ }

    db.close();
    return NextResponse.json({
      ok: true,
      mode: "bot_broadcast",
      message: `پیام دسته‌جمعی در صف ربات قرار گرفت. ربات ظرف ۱۵ ثانیه شروع به ارسال می‌کند.`,
      estimated_recipients: userCount,
    });

  } catch (e) {
    try { db.close(); } catch { /* */ }
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
