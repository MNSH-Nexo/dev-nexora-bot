/**
 * POST /api/manual-sub
 * اشتراک دستی — وظیفه ساخت اشتراک را به ربات تلگرام واگذار می‌کند.
 *
 * وب‌پنل فقط یک ردیف در pending_actions می‌نویسد.
 * ربات هر ۱۵ ثانیه آن را می‌خواند و با منطق کامل خودش اشتراک می‌سازه،
 * در DB ثبت می‌کنه و لینک رو به کاربر می‌فرسته.
 *
 * body: { user_id, telegram_id, mode: "plan"|"custom",
 *         plan_id?, traffic_gb?, days?, limit_ip? }
 */
import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({})) as Record<string, unknown>;
  const { user_id, telegram_id, mode, plan_id, traffic_gb, days, limit_ip } = body;

  if (!user_id || !telegram_id) {
    return NextResponse.json({ error: "user_id و telegram_id الزامی است" }, { status: 400 });
  }

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable — مسیر BOT_DB_PATH را بررسی کنید" }, { status: 503 });

  try {
    // اطمینان از وجود جدول pending_actions
    db.prepare(`
      CREATE TABLE IF NOT EXISTS pending_actions (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        type       TEXT    NOT NULL,
        payload    TEXT    NOT NULL DEFAULT '{}',
        created_at TEXT    NOT NULL DEFAULT (datetime('now'))
      )
    `).run();

    // ساخت payload برای ربات
    const payload: Record<string, unknown> = {
      user_id:     Number(user_id),
      telegram_id: Number(telegram_id),
    };

    if (mode === "plan" && plan_id) {
      payload.plan_id = Number(plan_id);
    } else {
      payload.traffic_gb  = Number(traffic_gb ?? 0);
      payload.expire_days = Number(days ?? 30);
      payload.limit_ip    = Number(limit_ip ?? 0);
    }

    db.prepare(
      "INSERT INTO pending_actions (type, payload, created_at) VALUES ('manual_sub', ?, datetime('now'))"
    ).run(JSON.stringify(payload));

    db.close();
    return NextResponse.json({
      ok: true,
      message: "دستور ساخت اشتراک برای ربات ارسال شد. ظرف ۱۵ ثانیه اشتراک ساخته و برای کاربر فرستاده می‌شود.",
    });

  } catch (e) {
    try { db.close(); } catch { /* ignore */ }
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
