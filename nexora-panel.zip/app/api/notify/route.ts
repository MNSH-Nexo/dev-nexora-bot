/**
 * POST /api/notify
 * ارسال پیام متنی یا عکس+کپشن به ادمین‌ها از طریق Telegram Bot API
 *
 * حالت JSON:  { message, target }         → sendMessage
 * حالت FormData: photo (File) + caption   → sendPhoto
 */
import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

async function tgSendMessage(token: string, chatId: string, text: string): Promise<boolean> {
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true }),
    });
    return ((await res.json()) as { ok: boolean }).ok === true;
  } catch { return false; }
}

async function tgSendPhoto(token: string, chatId: string, photoBytes: ArrayBuffer, caption: string): Promise<boolean> {
  try {
    const form = new FormData();
    form.append("chat_id", chatId);
    form.append("photo", new Blob([photoBytes], { type: "image/jpeg" }), "photo.jpg");
    if (caption) form.append("caption", caption);
    form.append("parse_mode", "HTML");
    const res = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, { method: "POST", body: form });
    return ((await res.json()) as { ok: boolean }).ok === true;
  } catch { return false; }
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const botToken = process.env.BOT_TOKEN ?? "";
  const adminIds = (process.env.ADMIN_IDS ?? "").split(",").map(s => s.trim()).filter(Boolean);

  if (!botToken)           return NextResponse.json({ error: "BOT_TOKEN not configured" }, { status: 503 });
  if (!adminIds.length)    return NextResponse.json({ error: "ADMIN_IDS not configured" }, { status: 503 });

  const ct = req.headers.get("content-type") ?? "";

  // ── حالت FormData — عکس + کپشن ─────────────────────────────
  if (ct.includes("multipart/form-data")) {
    const form = await req.formData().catch(() => null);
    if (!form) return NextResponse.json({ error: "invalid form data" }, { status: 400 });

    const photoFile = form.get("photo") as File | null;
    const caption   = String(form.get("caption") ?? "").trim();

    if (!photoFile) return NextResponse.json({ error: "photo is required" }, { status: 400 });

    const photoBytes = await photoFile.arrayBuffer();

    const results = await Promise.all(
      adminIds.map(id => tgSendPhoto(botToken, id, photoBytes, caption))
    );
    const sent = results.filter(Boolean).length;
    return NextResponse.json({ ok: true, sent, total: adminIds.length, failed: adminIds.length - sent });
  }

  // ── حالت JSON — پیام متنی ───────────────────────────────────
  const body = await req.json().catch(() => ({})) as Record<string, unknown>;
  const message = String(body.message ?? "").trim();

  if (!message) return NextResponse.json({ error: "message is required" }, { status: 400 });

  const results = await Promise.all(adminIds.map(id => tgSendMessage(botToken, id, message)));
  const sent = results.filter(Boolean).length;
  return NextResponse.json({ ok: true, sent, total: adminIds.length, failed: adminIds.length - sent });
}
