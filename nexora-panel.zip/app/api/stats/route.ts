import { NextResponse } from "next/server";
import { getBotDb } from "@/lib/botdb";
import { xuiGetServerStatus } from "@/lib/xui";
import { cookies } from "next/headers";

async function checkAuth(): Promise<boolean> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("nexora_session")?.value ?? "";
    if (token.length < 20) return false;
    const decoded = Buffer.from(token, "base64").toString("utf8");
    return decoded.split(":").length >= 3;
  } catch { return false; }
}

export async function GET() {
  if (!(await checkAuth())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  // دریافت موازی: DB stats + server status از 3X-UI
  const [db, serverStatus] = await Promise.all([
    Promise.resolve(getBotDb(true)),
    xuiGetServerStatus().catch(() => null),
  ]);

  const srv = serverStatus ? {
    cpu:  serverStatus.cpu,
    ram:  serverStatus.mem.total  > 0 ? Math.round(serverStatus.mem.used  / serverStatus.mem.total  * 100) : null,
    disk: serverStatus.disk.total > 0 ? Math.round(serverStatus.disk.used / serverStatus.disk.total * 100) : null,
    ramUsed:   serverStatus.mem.used,
    ramTotal:  serverStatus.mem.total,
    diskUsed:  serverStatus.disk.used,
    diskTotal: serverStatus.disk.total,
    uptime:    serverStatus.uptime,
    loads:     serverStatus.loads,
    xrayState: serverStatus.xrayState,
    xrayVersion: serverStatus.xrayVersion,
    panelVersion: serverStatus.panelVersion,
    tcpCount:  serverStatus.tcpCount,
    netIO:     serverStatus.netIO,
  } : { cpu: null, ram: null, disk: null };

  const empty = {
    source: "unavailable",
    totalUsers: 0, usersToday: 0, activeSubs: 0, expiringSoon: 0,
    revenueTotal: 0, revenueToday: 0, pendingPayments: 0, openTickets: 0,
    newUsers30d: 0, revenue30d: 0, soldSubs30d: 0, expiring30d: 0,
    subActive: 0, subExpired: 0, subDepleted: 0, subDisabled: 0,
    subActivePct: 0, subExpiredPct: 0, subDepletedPct: 0, subDisabledPct: 0,
    ...srv,
  };

  if (!db) return NextResponse.json(empty);

  try {
    const todayStart = new Date(); todayStart.setHours(0,0,0,0);
    const todayIso  = todayStart.toISOString();
    const now       = new Date().toISOString();
    const in7days   = new Date(Date.now() + 7  * 86400000).toISOString();
    const in30days  = new Date(Date.now() + 30 * 86400000).toISOString();
    const ago30days = new Date(Date.now() - 30 * 86400000).toISOString();

    const q = <T>(sql: string, ...p: unknown[]) =>
      (db.prepare(sql).get(...p) as T);

    const totalUsers      = q<{c:number}>("SELECT COUNT(*) as c FROM users").c;
    const usersToday      = q<{c:number}>("SELECT COUNT(*) as c FROM users WHERE created_at >= ?", todayIso).c;
    const activeSubs      = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE status='active' AND (expiry_date IS NULL OR expiry_date > ?)", now).c;
    const expiringSoon    = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE status='active' AND expiry_date BETWEEN ? AND ?", now, in7days).c;
    const revenueTotal    = q<{s:number}>("SELECT COALESCE(SUM(amount_usdt),0) as s FROM payments WHERE status IN ('confirmed','finished')").s;
    const revenueToday    = q<{s:number}>("SELECT COALESCE(SUM(amount_usdt),0) as s FROM payments WHERE status IN ('confirmed','finished') AND created_at >= ?", todayIso).s;
    const pendingPayments = q<{c:number}>("SELECT COUNT(*) as c FROM payments WHERE status IN ('awaiting_review','waiting','confirming')").c;
    const openTickets     = q<{c:number}>("SELECT COUNT(*) as c FROM tickets WHERE status IN ('open','in_progress')").c;
    const newUsers30d     = q<{c:number}>("SELECT COUNT(*) as c FROM users WHERE created_at >= ?", ago30days).c;
    const revenue30d      = q<{s:number}>("SELECT COALESCE(SUM(amount_usdt),0) as s FROM payments WHERE status IN ('confirmed','finished') AND created_at >= ?", ago30days).s;
    const soldSubs30d     = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE created_at >= ?", ago30days).c;
    const expiring30d     = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE status='active' AND expiry_date BETWEEN ? AND ?", now, in30days).c;
    const subActive       = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE status='active'").c;
    const subExpired      = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE status='expired'").c;
    const subDepleted     = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE status='depleted'").c;
    const subDisabled     = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE status='disabled'").c;
    const subTotal        = (subActive + subExpired + subDepleted + subDisabled) || 1;

    db.close();
    return NextResponse.json({
      source: "live",
      totalUsers, usersToday, activeSubs, expiringSoon,
      revenueTotal: +revenueTotal.toFixed(2),
      revenueToday: +revenueToday.toFixed(2),
      pendingPayments, openTickets,
      newUsers30d, revenue30d: +revenue30d.toFixed(2), soldSubs30d, expiring30d,
      subActive, subExpired, subDepleted, subDisabled,
      subActivePct:   Math.round(subActive   / subTotal * 100),
      subExpiredPct:  Math.round(subExpired  / subTotal * 100),
      subDepletedPct: Math.round(subDepleted / subTotal * 100),
      subDisabledPct: Math.round(subDisabled / subTotal * 100),
      ...srv,
    });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}
