/**
 * POST /api/backup
 *
 * Backup actions (JSON body { action }):
 *   backup_bot   → bot SQLite DB as zip → Telegram admins
 *   backup_panel → 3X-UI panel DB via XUI API + panel .env.local → zip → Telegram
 *   backup_both  → both of the above
 *
 * Restore (multipart form-data):
 *   field "file" → auto-detects zip/SQLite/CSV-zip → restores bot DB
 *     - .db / .sqlite → direct SQLite file replace
 *     - .zip containing *.db / *.sqlite → extracts and replaces
 *     - .zip containing *.csv (PG export) → imports CSVs into SQLite
 *
 * Reset (JSON body { action: "reset_confirm" }):
 *   Backs up first, then wipes users/subs/payments/tickets/referrals
 *   Keeps: plans, discount_codes, admin_settings
 */
import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";
import fs from "fs";
import path from "path";
import { createWriteStream } from "fs";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

// ── DB path resolution ──────────────────────────────────────
const BOT_DB_PATHS = [
  process.env.BOT_DB_PATH,
  "/opt/nexora-bot/data/bot_data.db",
  "/var/lib/docker/volumes/nexora_bot_data/_data/bot_data.db",
];

function findBotDbPath(): string | null {
  for (const p of BOT_DB_PATHS) {
    if (p && fs.existsSync(p)) return p;
  }
  return null;
}

// ── Send file via Telegram Bot API ─────────────────────────
async function sendFileToTelegram(
  botToken: string, chatId: string, fileBuffer: Buffer,
  filename: string, caption: string
): Promise<boolean> {
  try {
    const formData = new FormData();
    formData.append("chat_id", chatId);
    formData.append("caption", caption.slice(0, 1024));
    formData.append("document", new Blob([fileBuffer], { type: "application/octet-stream" }), filename);
    const res = await fetch(`https://api.telegram.org/bot${botToken}/sendDocument`, {
      method: "POST", body: formData,
    });
    return (await res.json()).ok === true;
  } catch { return false; }
}

// ── Minimal in-process zip (Buffer-level) ──────────────────
// Uses Node.js zlib for deflate — no external dependencies
async function buildZip(entries: { name: string; data: Buffer }[]): Promise<Buffer> {
  const { deflateRawSync } = await import("zlib");
  // Minimal ZIP implementation
  const encoder = new TextEncoder();
  const localHeaders: Buffer[] = [];
  const centralDirs: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes  = Buffer.from(entry.name, "utf8");
    const compressed = deflateRawSync(entry.data, { level: 6 });
    const crc = crc32(entry.data);

    // Local file header
    const local = Buffer.allocUnsafe(30 + nameBytes.length);
    local.writeUInt32LE(0x04034b50, 0);   // signature
    local.writeUInt16LE(20, 4);            // version needed
    local.writeUInt16LE(0, 6);             // flags
    local.writeUInt16LE(8, 8);             // deflate
    local.writeUInt16LE(0, 10);            // mod time
    local.writeUInt16LE(0, 12);            // mod date
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(compressed.length, 18);
    local.writeUInt32LE(entry.data.length, 22);
    local.writeUInt16LE(nameBytes.length, 26);
    local.writeUInt16LE(0, 28);
    nameBytes.copy(local, 30);

    localHeaders.push(local);
    localHeaders.push(compressed);

    // Central directory
    const central = Buffer.allocUnsafe(46 + nameBytes.length);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0, 8);
    central.writeUInt16LE(8, 10);
    central.writeUInt16LE(0, 12);
    central.writeUInt16LE(0, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(compressed.length, 20);
    central.writeUInt32LE(entry.data.length, 24);
    central.writeUInt16LE(nameBytes.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    nameBytes.copy(central, 46);
    centralDirs.push(central);
    offset += local.length + compressed.length;
  }

  const centralBuf  = Buffer.concat(centralDirs);
  const eocd        = Buffer.allocUnsafe(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localHeaders, centralBuf, eocd]);
}

function crc32(buf: Buffer): number {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c;
  }
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

// ── Extract zip in-process ──────────────────────────────────
function extractZip(zipBuf: Buffer): Map<string, Buffer> {
  const files = new Map<string, Buffer>();
  let pos = 0;
  while (pos < zipBuf.length - 4) {
    const sig = zipBuf.readUInt32LE(pos);
    if (sig !== 0x04034b50) { pos++; continue; }
    const method     = zipBuf.readUInt16LE(pos + 8);
    const compSize   = zipBuf.readUInt32LE(pos + 18);
    const uncompSize = zipBuf.readUInt32LE(pos + 22);
    const nameLen    = zipBuf.readUInt16LE(pos + 26);
    const extraLen   = zipBuf.readUInt16LE(pos + 28);
    const name = zipBuf.slice(pos + 30, pos + 30 + nameLen).toString("utf8");
    const dataStart = pos + 30 + nameLen + extraLen;
    const compData  = zipBuf.slice(dataStart, dataStart + compSize);
    if (method === 0) {
      files.set(name, compData);
    } else if (method === 8) {
      try {
        const { inflateRawSync } = require("zlib");
        files.set(name, inflateRawSync(compData));
      } catch { /* skip */ }
    }
    pos = dataStart + compSize;
  }
  return files;
}

// ── Fetch 3X-UI panel DB via API ────────────────────────────
async function fetchXuiPanelDb(): Promise<Buffer | null> {
  // از xuiGetInbounds با pattern یکسان استفاده می‌کنیم
  // xuiLogin اکنون فقط cookie از login response برمی‌گرداند (نه ترکیبی)
  const { xuiLogin, getPanelStatus } = await import("@/lib/xui");
  const { configured, url } = getPanelStatus();
  if (!configured) return null;
  try {
    const cookie = await xuiLogin();
    if (!cookie) return null;
    const prev = process.env.NODE_TLS_REJECT_UNAUTHORIZED;
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    const dbRes = await fetch(`${url}/panel/api/server/getDb`, {
      headers: {
        Cookie: cookie,
        Accept: "application/octet-stream",
      },
      signal: AbortSignal.timeout(30_000),
    }).finally(() => {
      if (prev === undefined) delete process.env.NODE_TLS_REJECT_UNAUTHORIZED;
      else process.env.NODE_TLS_REJECT_UNAUTHORIZED = prev;
    });
    if (!dbRes.ok) return null;
    return Buffer.from(await dbRes.arrayBuffer());
  } catch { return null; }
}

// ── CSV → SQLite import ─────────────────────────────────────
function importCsvToSqlite(db: import("better-sqlite3").Database, csvMap: Map<string, Buffer>): string[] {
  const log: string[] = [];
  for (const [fname, buf] of csvMap) {
    const tableName = fname.replace(/\.csv$/i, "");
    const content = buf.toString("utf8").trim();
    if (!content || content === "empty") continue;
    const lines = content.split("\n");
    if (lines.length < 2) continue;
    const cols = lines[0].split(",").map(c => c.trim().replace(/^"|"$/g, ""));
    // Check table exists
    const tableExists = db.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
    ).get(tableName);
    if (!tableExists) { log.push(`⚠️ جدول ${tableName} در دیتابیس موجود نیست — رد شد`); continue; }
    let inserted = 0;
    const stmt = db.prepare(
      `INSERT OR REPLACE INTO "${tableName}" (${cols.map(c => `"${c}"`).join(",")}) VALUES (${cols.map(() => "?").join(",")})`
    );
    const txn = db.transaction(() => {
      for (let i = 1; i < lines.length; i++) {
        const row = parseCSVLine(lines[i]);
        if (row.length !== cols.length) continue;
        try { stmt.run(...row.map(v => v === "" ? null : v)); inserted++; } catch { /* row skip */ }
      }
    });
    txn();
    log.push(`✅ ${tableName}: ${inserted} ردیف وارد شد`);
  }
  return log;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let cur = ""; let inQuote = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') { if (inQuote && line[i+1] === '"') { cur += '"'; i++; } else inQuote = !inQuote; }
    else if (c === ',' && !inQuote) { result.push(cur); cur = ""; }
    else cur += c;
  }
  result.push(cur);
  return result;
}

// ════════════════════════════════════════════
// Route handler
// ════════════════════════════════════════════
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const contentType = req.headers.get("content-type") ?? "";

  // ── RESTORE (multipart) ────────────────────────────────────
  if (contentType.includes("multipart/form-data")) {
    const form = await req.formData();
    const file = form.get("file") as File | null;
    if (!file) return NextResponse.json({ error: "No file provided" }, { status: 400 });

    const dbPath = findBotDbPath();
    if (!dbPath) return NextResponse.json({ error: "مسیر دیتابیس ربات روی سرور پیدا نشد" }, { status: 503 });

    try {
      const rawBuf = Buffer.from(await file.arrayBuffer());
      const fname  = file.name.toLowerCase();

      // Backup current DB first
      const backupPath = dbPath + ".before_restore_" + Date.now();
      fs.copyFileSync(dbPath, backupPath);

      // ── Case 1: direct .db / .sqlite file ─────────────────
      if (fname.endsWith(".db") || fname.endsWith(".sqlite") || fname.endsWith(".sqlite3")) {
        fs.writeFileSync(dbPath, rawBuf);
        return NextResponse.json({ ok: true, message: "✅ دیتابیس SQLite با موفقیت بازگردانی شد. ربات را ری‌استارت کنید." });
      }

      // ── Case 2: .zip ───────────────────────────────────────
      if (fname.endsWith(".zip")) {
        const entries = extractZip(rawBuf);

        // Find .db inside zip (SQLite backup)
        const dbEntry = [...entries.entries()].find(([n]) =>
          n.endsWith(".db") || n.endsWith(".sqlite") || n.endsWith(".sqlite3")
        );
        if (dbEntry) {
          fs.writeFileSync(dbPath, dbEntry[1]);
          return NextResponse.json({ ok: true, message: `✅ فایل SQLite از داخل zip بازگردانی شد (${dbEntry[0]}). ربات را ری‌استارت کنید.` });
        }

        // Find .csv files (PostgreSQL export)
        const csvFiles = new Map<string, Buffer>();
        for (const [n, buf] of entries) {
          if (n.endsWith(".csv")) csvFiles.set(n.replace(/\.csv$/i, "").split("/").pop()!, buf);
        }
        if (csvFiles.size > 0) {
          const db = getBotDb(false);
          if (!db) return NextResponse.json({ error: "نمی‌توان دیتابیس را برای نوشتن باز کرد" }, { status: 503 });
          const importLog = importCsvToSqlite(db, csvFiles);
          db.close();
          return NextResponse.json({
            ok: true,
            message: `✅ ${csvFiles.size} جدول CSV از بک‌آپ PostgreSQL وارد شد.`,
            details: importLog,
          });
        }

        return NextResponse.json({ error: "هیچ فایل .db یا .csv در داخل zip پیدا نشد" }, { status: 400 });
      }

      return NextResponse.json({ error: "فرمت فایل پشتیبانی نمی‌شود (.db / .sqlite / .zip)" }, { status: 400 });
    } catch (e) {
      return NextResponse.json({ error: String(e) }, { status: 500 });
    }
  }

  // ── JSON actions ───────────────────────────────────────────
  const body = await req.json().catch(() => ({}));
  const { action } = body;
  const botToken = process.env.BOT_TOKEN ?? "";
  const adminIds: string[] = (process.env.ADMIN_IDS ?? "").split(",").map((s: string) => s.trim()).filter(Boolean);

  // ── BACKUP ─────────────────────────────────────────────────
  if (["backup_bot", "backup_panel", "backup_both"].includes(action)) {
    if (!botToken || adminIds.length === 0) {
      return NextResponse.json({ error: "BOT_TOKEN یا ADMIN_IDS در .env.local تنظیم نشده" }, { status: 503 });
    }
    const now = new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-");
    const results: string[] = [];

    // Bot DB backup
    if (action === "backup_bot" || action === "backup_both") {
      const dbPath = findBotDbPath();
      if (!dbPath) {
        results.push("❌ دیتابیس ربات روی سرور پیدا نشد");
      } else {
        try {
          const dbBuf = fs.readFileSync(dbPath);
          const zipBuf = await buildZip([{ name: `bot_data_${now}.db`, data: dbBuf }]);
          let sent = 0;
          for (const id of adminIds) {
            if (await sendFileToTelegram(botToken, id, zipBuf, `bot_backup_${now}.zip`,
              `🗄 بک‌آپ دیتابیس ربات\n📅 ${now}\n📦 ${(zipBuf.length/1024).toFixed(1)} KB\n\n♻️ برای restore: پنل ← سرور ← بازگردانی ← آپلود این فایل`)) sent++;
          }
          results.push(`✅ دیتابیس ربات (${(dbBuf.length/1024).toFixed(0)} KB): ارسال به ${sent}/${adminIds.length} ادمین`);
        } catch (e) { results.push(`❌ خطا در بک‌آپ ربات: ${String(e).slice(0,100)}`); }
      }
    }

    // Panel DB backup (3X-UI)
    if (action === "backup_panel" || action === "backup_both") {
      const xuiDb = await fetchXuiPanelDb();
      if (!xuiDb) {
        results.push("⚠️ دیتابیس 3X-UI در دسترس نیست — بک‌آپ .env.local پنل ارسال می‌شود");
      } else {
        const zipBuf = await buildZip([{ name: `x-ui_${now}.db`, data: xuiDb }]);
        let sent = 0;
        for (const id of adminIds) {
          if (await sendFileToTelegram(botToken, id, zipBuf, `xui_backup_${now}.zip`,
            `🖥 بک‌آپ پنل 3X-UI\n📅 ${now}\n📦 ${(zipBuf.length/1024).toFixed(1)} KB\n\n⚠️ برای restore از رابط وب 3X-UI استفاده کنید (Settings → Import DB)`)) sent++;
        }
        results.push(`✅ دیتابیس 3X-UI (${(xuiDb.length/1024).toFixed(0)} KB): ارسال به ${sent}/${adminIds.length} ادمین`);
      }

      // Also send .env.local (panel config)
      const panelEnv = "/opt/nexora-panel/.env.local";
      if (fs.existsSync(panelEnv)) {
        const envBuf = fs.readFileSync(panelEnv);
        const zipBuf = await buildZip([{ name: `panel_env_${now}.txt`, data: envBuf }]);
        let sent = 0;
        for (const id of adminIds) {
          if (await sendFileToTelegram(botToken, id, zipBuf, `panel_env_${now}.zip`,
            `⚙️ بک‌آپ تنظیمات پنل ادمین\n📅 ${now}`)) sent++;
        }
        results.push(`✅ .env.local پنل: ارسال به ${sent}/${adminIds.length} ادمین`);
      }
    }

    return NextResponse.json({ ok: true, results });
  }

  // ── RESET DB ───────────────────────────────────────────────
  if (action === "reset_confirm") {
    const dbPath = findBotDbPath();
    if (!dbPath) return NextResponse.json({ error: "مسیر دیتابیس ربات پیدا نشد" }, { status: 503 });

    const db = getBotDb(false);
    if (!db) return NextResponse.json({ error: "نمی‌توان دیتابیس را باز کرد" }, { status: 503 });

    try {
      // Auto-backup before reset
      const backupPath = dbPath + ".before_reset_" + Date.now();
      fs.copyFileSync(dbPath, backupPath);

      // Tables to wipe (user data) — preserve plans/settings/discounts
      const wipe = ["referrals", "ticket_messages", "tickets", "subscriptions", "payments", "users"];
      for (const t of wipe) {
        try { db.prepare(`DELETE FROM "${t}"`).run(); } catch { /* table may not exist */ }
      }
      db.close();
      return NextResponse.json({
        ok: true,
        message: "✅ دیتابیس ریست شد — کاربران، اشتراک‌ها، پرداخت‌ها، تیکت‌ها و رفرال‌ها پاک شدند.\n⚙️ پلن‌ها، تنظیمات و کدهای تخفیف حفظ شدند.\n💾 بک‌آپ خودکار روی سرور ذخیره شد.",
        backupPath,
      });
    } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
  }

  return NextResponse.json({ error: "unknown action" }, { status: 400 });
}
