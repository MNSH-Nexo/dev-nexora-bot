import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth, getSetting } from "@/lib/botdb";

function auth(req: NextRequest) {
  return requireAuth(req as unknown as Request);
}

// ── GET /api/plans ──────────────────────────────────────────
export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const db = getBotDb(true);
  if (!db) return NextResponse.json({ plans: [], source: "unavailable" });

  try {
    const plans = db.prepare(
      "SELECT id, name, traffic_gb, duration_days, price_usdt, limit_ip, inbound_ids, is_active, sort_order FROM plans ORDER BY sort_order, id"
    ).all() as Array<{
      id: number; name: string; traffic_gb: number; duration_days: number;
      price_usdt: number; limit_ip: number; inbound_ids: string; is_active: number; sort_order: number;
    }>;

    db.close();
    return NextResponse.json({
      plans: plans.map(p => ({
        ...p,
        is_active: p.is_active === 1,
        inbound_ids: p.inbound_ids ? p.inbound_ids.split(",").filter(Boolean).map(Number) : [],
      })),
      source: "live",
    });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

// ── POST /api/plans ─────────────────────────────────────────
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const { name, traffic_gb, duration_days, price_usdt, limit_ip, inbound_ids, sort_order } = body;

  if (!name || price_usdt == null) {
    return NextResponse.json({ error: "name and price_usdt are required" }, { status: 400 });
  }

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    const now = new Date().toISOString();
    const inboundStr = Array.isArray(inbound_ids) ? inbound_ids.join(",") : (inbound_ids ?? "");
    const result = db.prepare(
      "INSERT INTO plans (name, traffic_gb, duration_days, price_usdt, limit_ip, inbound_ids, is_active, sort_order, created_at, updated_at) VALUES (?,?,?,?,?,?,1,?,?,?)"
    ).run(name, traffic_gb ?? 0, duration_days ?? 30, price_usdt, limit_ip ?? 0, inboundStr, sort_order ?? 0, now, now);

    db.close();
    return NextResponse.json({ id: result.lastInsertRowid, ok: true });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

// ── PUT /api/plans ──────────────────────────────────────────
export async function PUT(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const { id, ...fields } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  // Normalize inbound_ids array → comma string
  if (Array.isArray(fields.inbound_ids)) {
    fields.inbound_ids = fields.inbound_ids.join(",");
  }
  // Normalize boolean
  if (fields.is_active !== undefined) {
    fields.is_active = fields.is_active ? 1 : 0;
  }
  fields.updated_at = new Date().toISOString();

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    const cols = Object.keys(fields).map(k => `${k} = ?`).join(", ");
    const vals = Object.values(fields);
    db.prepare(`UPDATE plans SET ${cols} WHERE id = ?`).run(...vals, id);
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

// ── DELETE /api/plans ───────────────────────────────────────
export async function DELETE(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    db.prepare("DELETE FROM plans WHERE id = ?").run(Number(id));
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
