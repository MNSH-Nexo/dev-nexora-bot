#!/bin/bash
# ─────────────────────────────────────────────
# Nexora Web Panel — Install / Update Script
# ─────────────────────────────────────────────
set -e

PANEL_DIR="/opt/nexora-panel"
SERVICE_NAME="nexora-panel"
DEFAULT_PORT=3000

echo ""
echo "══════════════════════════════════════════"
echo "  Nexora Web Panel — Installer"
echo "══════════════════════════════════════════"
echo ""

# ── خواندن پورت از سرویس فعلی (اگر نصب قبلی وجود داشت) ──
CURRENT_PORT=""
if [ -f "/etc/systemd/system/${SERVICE_NAME}.service" ]; then
  CURRENT_PORT=$(grep -oP '(?<=-- -p )\d+' /etc/systemd/system/${SERVICE_NAME}.service 2>/dev/null || echo "")
fi

# ── پرسیدن پورت ──
if [ -n "$CURRENT_PORT" ]; then
  echo "پورت فعلی پنل: $CURRENT_PORT"
  read -p "پورت جدید [Enter برای حفظ پورت فعلی]: " INPUT_PORT
  PORT=${INPUT_PORT:-$CURRENT_PORT}
else
  read -p "پورت پنل وب (پیش‌فرض: 3000): " INPUT_PORT
  PORT=${INPUT_PORT:-$DEFAULT_PORT}
fi

# ── پیدا کردن مسیر دیتابیس ربات ──
# ربات داخل Docker اجرا میشه و DB در volume ذخیره میشه
DB_PATH=""
CANDIDATES=(
  "/var/lib/docker/volumes/nexora_bot_data/_data/bot_data.db"
  "/opt/nexora-bot/data/bot_data.db"
  "/opt/nexora-bot/bot/bot_data.db"
)
for p in "${CANDIDATES[@]}"; do
  if [ -f "$p" ]; then
    DB_PATH="$p"
    echo "✅ دیتابیس ربات پیدا شد: $DB_PATH"
    break
  fi
done
if [ -z "$DB_PATH" ]; then
  echo "⚠️  دیتابیس ربات پیدا نشد. بعد از راه‌اندازی ربات، مسیر رو دستی در .env.local تنظیم کنید:"
  echo "   BOT_DB_PATH=/var/lib/docker/volumes/nexora_bot_data/_data/bot_data.db"
  DB_PATH="/var/lib/docker/volumes/nexora_bot_data/_data/bot_data.db"
fi

# ── اگر سرویس در حال اجراست، متوقفش کن ──
if systemctl is-active --quiet ${SERVICE_NAME} 2>/dev/null; then
  echo "⏹  متوقف کردن سرویس قدیمی..."
  systemctl stop ${SERVICE_NAME}
fi

# ── نصب pnpm اگر نیست ──
if ! command -v pnpm &>/dev/null; then
  echo "📦 نصب pnpm..."
  npm install -g pnpm
fi

# ── ساخت یا آپدیت .env.local ──
ENV_FILE="${PANEL_DIR}/.env.local"
if [ ! -f "$ENV_FILE" ]; then
  echo "📝 ساخت .env.local..."
  cat > "$ENV_FILE" << ENVEOF
# Nexora Web Panel — Environment Variables
# این فایل توسط install.sh ساخته شده

# مسیر دیتابیس ربات (SQLite)
BOT_DB_PATH=${DB_PATH}

# تنظیمات وب پنل (از .env ربات کپی کنید)
# WEB_PANEL_USER=admin
# WEB_PANEL_PASS=admin1234
# WEB_PANEL_PATH=/mySecretPath

# اطلاعات ربات (از .env ربات کپی کنید)
# BOT_TOKEN=
# ADMIN_IDS=
# PANEL_URL=
# PANEL_USERNAME=
# PANEL_PASSWORD=
ENVEOF
  echo "✅ .env.local ساخته شد — لطفاً مقادیر رو تکمیل کنید"
else
  # فقط BOT_DB_PATH رو آپدیت کن اگه تغییر کرده
  if grep -q "BOT_DB_PATH=" "$ENV_FILE"; then
    sed -i "s|BOT_DB_PATH=.*|BOT_DB_PATH=${DB_PATH}|" "$ENV_FILE"
  else
    echo "BOT_DB_PATH=${DB_PATH}" >> "$ENV_FILE"
  fi
  echo "✅ BOT_DB_PATH در .env.local آپدیت شد: ${DB_PATH}"
fi

# ── نصب وابستگی‌ها ──
echo "📦 نصب وابستگی‌ها..."
cd "${PANEL_DIR}"
pnpm install --frozen-lockfile 2>/dev/null || pnpm install

# ── build ──
echo "🔨 Build پنل..."
pnpm build

# ── ساخت فایل systemd service ──
echo "⚙️  ساخت سرویس systemd..."
cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=Nexora Web Admin Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=${PANEL_DIR}
EnvironmentFile=${PANEL_DIR}/.env.local
ExecStart=$(which pnpm) start -- -p ${PORT}
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# ── reload و start سرویس ──
systemctl daemon-reload
systemctl enable ${SERVICE_NAME}
systemctl start ${SERVICE_NAME}

sleep 2
if systemctl is-active --quiet ${SERVICE_NAME}; then
  echo ""
  echo "✅ پنل با موفقیت نصب و راه‌اندازی شد!"
  echo ""
  echo "  پورت: ${PORT}"
  echo "  وضعیت: systemctl status ${SERVICE_NAME}"
  echo "  لاگ:   journalctl -u ${SERVICE_NAME} -f"
else
  echo ""
  echo "❌ خطا در راه‌اندازی سرویس. لاگ:"
  journalctl -u ${SERVICE_NAME} --no-pager -n 30
fi
