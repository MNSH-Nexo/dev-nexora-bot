/**
 * lib/botdb.ts — v2 (VPS-patched)
 * تغییر: require() به جای import برای جلوگیری از module-level crash
 * اگه better-sqlite3 به هر دلیل load نشه (ABI mismatch، compile error)،
 * با import static کل ماژول crash می‌کنه. با require() فقط getBotDb
 * null برمی‌گرده و خطا لاگ می‌شه.
 */
import fs from "fs";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let _Sqlite: any = null;
let _sqliteErr: string | null = null;

function getSqlite() {
  if (_Sqlite !== null) return _Sqlite;
  if (_sqliteErr !== null) return null;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    _Sqlite = require("better-sqlite3");
    return _Sqlite;
  } catch (e) {
    _sqliteErr = String(e);
    console.error("[botdb] better-sqlite3 failed to load:", _sqliteErr);
    return null;
  }
}

// warm-up at module load (non-blocking)
getSqlite();

/** همه مسیرهای ممکن DB — هر بار از process.env می‌خونه (نه static) */
function getDbCandidates(): string[] {
  const candidates: string[] = [];

  // 1. از env var (systemd EnvironmentFile یا .env.local)
  const envPath = process.env.BOT_DB_PATH?.trim();
  if (envPath) candidates.push(envPath);

  // 2. Docker volume — مسیر استاندارد nexora (ربات با Docker اجرا می‌شه)
  candidates.push("/var/lib/docker/volumes/nexora_bot_data/_data/bot_data.db");

  // 3. fallback‌های دیگر
  candidates.push("/opt/nexora-bot/data/bot_data.db");
  candidates.push("/opt/nexora-bot/bot/bot_data.db");

  return candidates;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getBotDb(readonly = true): any | null {
  const Sqlite = getSqlite();
  if (!Sqlite) {
    console.error("[botdb] better-sqlite3 not available. load error:", _sqliteErr);
    return null;
  }
  for (const p of getDbCandidates()) {
    if (!fs.existsSync(p)) continue;
    try {
      const db = new Sqlite(p, { readonly, fileMustExist: true });
      return db;
    } catch (e) {
      console.error(`[botdb] open failed for ${p}:`, String(e));
      continue;
    }
  }
  console.error("[botdb] no DB found in candidates:", getDbCandidates());
  return null;
}

/** مسیر فایل DB که الان استفاده می‌شه — برای debug */
export function getBotDbPath(): string | null {
  for (const p of getDbCandidates()) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

/** همه مسیرها + وضعیت sqlite module — برای debug */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getDbDiagnostics(): Record<string, any> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const result: Record<string, any> = {};
  for (const p of getDbCandidates()) {
    result[p] = fs.existsSync(p);
  }
  result["__sqlite_loaded"] = _Sqlite !== null;
  result["__sqlite_error"]  = _sqliteErr ?? "none";
  return result;
}

/** Auth helper — reused across all API routes */
export function requireAuth(req: Request): boolean {
  const cookie = req.headers.get("cookie") ?? "";
  if (!cookie.includes("nexora_session=")) return false;
  const token = cookie.split("nexora_session=")[1]?.split(";")[0]?.trim() ?? "";
  if (token.length < 20) return false;
  // validate: باید base64 و شامل ":" (از username:timestamp:random) باشه
  try {
    const decoded = Buffer.from(token, "base64").toString("utf8");
    // فرمت: username:timestamp:random — حداقل 2 تا ":" داره
    return decoded.split(":").length >= 3;
  } catch {
    return false;
  }
}

/** Read a single admin_setting value */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getSetting(db: any, key: string, def = ""): string {
  try {
    const row = db.prepare("SELECT value FROM admin_settings WHERE key = ?").get(key) as { value: string } | undefined;
    return row?.value ?? def;
  } catch { return def; }
}

/** Upsert an admin_setting value */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function setSetting(db: any, key: string, value: string): void {
  db.prepare(
    "INSERT INTO admin_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value"
  ).run(key, value);
}
