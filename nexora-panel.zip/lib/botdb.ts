/**
 * lib/botdb.ts
 * دسترسی read-write به دیتابیس SQLite ربات (better-sqlite3).
 *
 * ترتیب اولویت مسیریابی DB (هر بار runtime — نه module-load-time):
 *  1. BOT_DB_PATH از process.env (تنظیم‌شده توسط .env.local)
 *  2. Docker volume مستقیم (مسیر استاندارد nexora)
 *  3. مسیرهای fallback دیگر
 *  4. اگه هیچ‌کدام نبود → null (پنل در حالت demo کار می‌کنه)
 */
import Database from "better-sqlite3";
import fs from "fs";

/** همه مسیرهای ممکن DB — هر بار از process.env می‌خونه (نه static) */
function getDbCandidates(): string[] {
  const candidates: string[] = [];

  // 1. از env var (systemd EnvironmentFile یا .env.local)
  const envPath = process.env.BOT_DB_PATH?.trim();
  if (envPath) candidates.push(envPath);

  // 2. Docker volume — مسیر استاندارد nexora (ربات با Docker اجرا می‌شه)
  candidates.push("/var/lib/docker/volumes/nexora_bot_data/_data/bot_data.db");

  // 3. fallback‌های دیگر
  candidates.push("/opt/nexora-bot/data/bot_data.db");
  candidates.push("/opt/nexora-bot/bot/bot_data.db");

  return candidates;
}

export function getBotDb(readonly = true): Database.Database | null {
  for (const p of getDbCandidates()) {
    if (!fs.existsSync(p)) continue;
    try {
      return new Database(p, { readonly, fileMustExist: true });
    } catch {
      continue;
    }
  }
  return null;
}

/** مسیر فایل DB که الان استفاده می‌شه — برای debug */
export function getBotDbPath(): string | null {
  for (const p of getDbCandidates()) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

/** همه مسیرها و وضعیت وجود فایل — برای debug */
export function getDbDiagnostics(): Record<string, boolean> {
  const result: Record<string, boolean> = {};
  for (const p of getDbCandidates()) {
    result[p] = fs.existsSync(p);
  }
  return result;
}

/** Auth helper — reused across all API routes */
export function requireAuth(req: Request): boolean {
  const cookie = req.headers.get("cookie") ?? "";
  if (!cookie.includes("nexora_session=")) return false;
  const token = cookie.split("nexora_session=")[1]?.split(";")[0]?.trim() ?? "";
  if (token.length < 20) return false;
  // validate: باید base64 و شامل ":" (از username:timestamp:random) باشه
  try {
    const decoded = Buffer.from(token, "base64").toString("utf8");
    // فرمت: username:timestamp:random — حداقل 2 تا ":" داره
    return decoded.split(":").length >= 3;
  } catch {
    return false;
  }
}

/** Read a single admin_setting value */
export function getSetting(db: Database.Database, key: string, def = ""): string {
  try {
    const row = db.prepare("SELECT value FROM admin_settings WHERE key = ?").get(key) as { value: string } | undefined;
    return row?.value ?? def;
  } catch {
    return def;
  }
}

/** Upsert an admin_setting value */
export function setSetting(db: Database.Database, key: string, value: string): void {
  db.prepare(
    "INSERT INTO admin_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value"
  ).run(key, value);
}
