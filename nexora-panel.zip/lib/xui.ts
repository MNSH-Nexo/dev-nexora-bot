/**
 * lib/xui.ts — v2
 * کلاینت مرکزی برای اتصال به پنل 3X-UI
 *
 * دقیقاً مثل XUIClient ربات پایتون کار می‌کند:
 *   1. GET به /  → دریافت CSRF token از <meta name="csrf-token">
 *   2. POST /login با JSON + X-CSRF-Token header
 *   3. نگه‌داری cookie session برای درخواست‌های بعدی
 *   4. Re-login خودکار روی 401
 *   5. SSL verify=false برای self-signed / Cloudflare proxy
 */

// ── config ────────────────────────────────────────────────────

function getPanelConfig() {
  const url      = (process.env.PANEL_URL      ?? "").trim().replace(/\/$/, "");
  const username = (process.env.PANEL_USERNAME ?? "admin").trim();
  const password = (process.env.PANEL_PASSWORD ?? "").trim();
  return { url, username, password };
}

// ── TLS bypass ────────────────────────────────────────────────

function withTlsBypass<T>(fn: () => Promise<T>): Promise<T> {
  const prev = process.env.NODE_TLS_REJECT_UNAUTHORIZED;
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  return fn().finally(() => {
    if (prev === undefined) delete process.env.NODE_TLS_REJECT_UNAUTHORIZED;
    else process.env.NODE_TLS_REJECT_UNAUTHORIZED = prev;
  });
}

// ── cookie extraction ─────────────────────────────────────────

function extractCookies(res: Response): string {
  if (typeof res.headers.getSetCookie === "function") {
    const cookies = res.headers.getSetCookie();
    if (cookies.length > 0) return cookies.map((c: string) => c.split(";")[0]).join("; ");
  }
  const single = res.headers.get("set-cookie") ?? "";
  return single ? single.split(";")[0] : "";
}

// ── CSRF token parser ─────────────────────────────────────────

function extractCsrfToken(html: string): string {
  const m = html.match(/<meta\s+name=["']csrf-token["']\s+content=["']([^"']+)["']/i)
         ?? html.match(/<meta\s+content=["']([^"']+)["']\s+name=["']csrf-token["']/i);
  return m?.[1] ?? "";
}

// ── module-level session singleton ───────────────────────────

let _sessionCookie = "";
let _csrfToken     = "";
let _loggedIn      = false;

function resetSession() {
  _sessionCookie = "";
  _csrfToken     = "";
  _loggedIn      = false;
}

// ── Step 1: دریافت CSRF token از صفحه اصلی ───────────────────

async function fetchCsrfToken(panelUrl: string): Promise<{ cookie: string; csrf: string }> {
  return withTlsBypass(async () => {
    try {
      const res = await fetch(`${panelUrl}/`, {
        method:  "GET",
        headers: {
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept-Language": "en-US,en;q=0.9",
        },
        signal:  AbortSignal.timeout(15_000),
      });
      const initialCookie = extractCookies(res);
      const html = await res.text();
      const csrf = extractCsrfToken(html);
      return { cookie: initialCookie, csrf };
    } catch {
      return { cookie: "", csrf: "" };
    }
  });
}

// ── Step 2: POST /login با JSON ───────────────────────────────

async function performLogin(
  panelUrl: string,
  username: string,
  password: string,
  initialCookie: string,
  csrfToken: string,
): Promise<string | null> {
  return withTlsBypass(async () => {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Accept:         "application/json",
      "User-Agent":   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Origin":       panelUrl,
      "Referer":      `${panelUrl}/`,
    };
    if (initialCookie) headers["Cookie"]       = initialCookie;
    if (csrfToken)     headers["X-CSRF-Token"] = csrfToken;

    const res = await fetch(`${panelUrl}/login`, {
      method:  "POST",
      headers,
      body:    JSON.stringify({ username, password }),
      signal:  AbortSignal.timeout(15_000),
    });

    if (!res.ok) return null;

    // پنل 3X-UI بعد از لاگین، session cookie جدید می‌فرسته
    // باید initial cookie + session cookie هر دو با هم ترکیب بشن
    // چون پنل با webBasePath کار می‌کنه و به هر دو نیاز داره
    const loginCookie = extractCookies(res);
    if (!loginCookie) return null;

    // ترکیب: session cookie جدید اولویت داره (اگه کلید تکراری بود override میشه)
    if (initialCookie && initialCookie !== loginCookie) {
      const initPairs = Object.fromEntries(
        initialCookie.split(";").map(s => s.trim().split("=", 2) as [string, string])
      );
      const loginPairs = Object.fromEntries(
        loginCookie.split(";").map(s => s.trim().split("=", 2) as [string, string])
      );
      const merged = { ...initPairs, ...loginPairs };
      return Object.entries(merged).map(([k, v]) => `${k}=${v}`).join("; ");
    }
    return loginCookie;
  });
}

// ── xuiLogin (export) ─────────────────────────────────────────

export async function xuiLogin(): Promise<string | null> {
  const { url, username, password } = getPanelConfig();
  if (!url || !password) return null;

  try {
    const { cookie: initCookie, csrf } = await fetchCsrfToken(url);
    const sessionCookie = await performLogin(url, username, password, initCookie, csrf);
    if (!sessionCookie) return null;

    _sessionCookie = sessionCookie;
    _csrfToken     = csrf;
    _loggedIn      = true;
    return sessionCookie;
  } catch {
    resetSession();
    return null;
  }
}

// ── fetch wrapper با session ──────────────────────────────────

async function xuiFetchWithSession(
  url: string,
  init: RequestInit = {},
): Promise<Response | null> {
  if (!_loggedIn) {
    const ok = await xuiLogin();
    if (!ok) return null;
  }

  return withTlsBypass(async () => {
    const { url: panelUrl } = getPanelConfig();
    const headers: Record<string, string> = {
      ...(init.headers as Record<string, string> ?? {}),
      "Cookie":       _sessionCookie,
      "User-Agent":   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Referer":      `${panelUrl}/`,
    };
    if (_csrfToken) headers["X-CSRF-Token"] = _csrfToken;

    const res = await fetch(url, {
      ...init,
      headers,
      signal: init.signal ?? AbortSignal.timeout(15_000),
    });

    if (res.status === 401) {
      resetSession();
      const ok = await xuiLogin();
      if (!ok) return null;
      return withTlsBypass(() => fetch(url, {
        ...init,
        headers: {
          ...(init.headers as Record<string, string> ?? {}),
          Cookie:         _sessionCookie,
          "X-CSRF-Token": _csrfToken,
          "User-Agent":   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
        signal: AbortSignal.timeout(15_000),
      }));
    }

    return res;
  });
}

// ── xuiGetInbounds (export) ───────────────────────────────────

export async function xuiGetInbounds(): Promise<Array<Record<string, unknown>> | null> {
  const { url } = getPanelConfig();
  if (!url) return null;

  try {
    const res = await xuiFetchWithSession(`${url}/panel/api/inbounds/list`, {
      headers: { Accept: "application/json" },
    });
    if (!res || !res.ok) return null;

    const data = await res.json() as { success: boolean; obj?: unknown[] };
    if (!data.success) return null;
    return (data.obj as Array<Record<string, unknown>>) ?? null;
  } catch {
    return null;
  }
}

// ── xuiGetServerStatus (export) ──────────────────────────────

export type XuiServerStatus = {
  cpu: number;          // درصد ۰-۱۰۰
  cpuCores: number;
  mem: { used: number; total: number };   // bytes
  swap: { used: number; total: number };
  disk: { used: number; total: number };
  uptime: number;       // ثانیه
  loads: number[];      // [1m, 5m, 15m]
  xrayState: string;    // "running" | "stopped" | ...
  xrayVersion: string;
  panelVersion: string;
  netIO: { up: number; down: number };    // bytes/s لحظه‌ای
  tcpCount: number;
  udpCount: number;
};

export async function xuiGetServerStatus(): Promise<XuiServerStatus | null> {
  const { url } = getPanelConfig();
  if (!url) return null;

  try {
    const res = await xuiFetchWithSession(`${url}/panel/api/server/status`, {
      headers: { Accept: "application/json" },
    });
    if (!res || !res.ok) return null;

    const data = await res.json() as { success: boolean; obj?: Record<string, unknown> };
    if (!data.success || !data.obj) return null;

    const o = data.obj;
    const mem  = o.mem  as { current: number; total: number } | undefined;
    const swap = o.swap as { current: number; total: number } | undefined;
    const disk = o.disk as { current: number; total: number } | undefined;
    const xray = o.xray as { state: string; version: string } | undefined;
    const netIO = o.netIO as { up: number; down: number } | undefined;

    return {
      cpu:          typeof o.cpu === "number" ? Math.round(o.cpu) : 0,
      cpuCores:     typeof o.cpuCores === "number" ? o.cpuCores : 1,
      mem:  { used: mem?.current  ?? 0, total: mem?.total  ?? 0 },
      swap: { used: swap?.current ?? 0, total: swap?.total ?? 0 },
      disk: { used: disk?.current ?? 0, total: disk?.total ?? 0 },
      uptime:       typeof o.uptime === "number" ? o.uptime : 0,
      loads:        Array.isArray(o.loads) ? (o.loads as number[]) : [0, 0, 0],
      xrayState:    xray?.state   ?? "unknown",
      xrayVersion:  xray?.version ?? "",
      panelVersion: typeof o.panelVersion === "string" ? o.panelVersion : "",
      netIO: { up: netIO?.up ?? 0, down: netIO?.down ?? 0 },
      tcpCount:     typeof o.tcpCount === "number" ? o.tcpCount : 0,
      udpCount:     typeof o.udpCount === "number" ? o.udpCount : 0,
    };
  } catch {
    return null;
  }
}

// ── xuiPing (export) ──────────────────────────────────────────

export async function xuiPing(): Promise<{
  reachable: boolean;
  loginOk: boolean;
  csrfFound: boolean;
  error?: string;
}> {
  const { url, password } = getPanelConfig();
  if (!url)      return { reachable: false, loginOk: false, csrfFound: false, error: "PANEL_URL not set" };
  if (!password) return { reachable: false, loginOk: false, csrfFound: false, error: "PANEL_PASSWORD not set" };

  try {
    const { url: u, username, password: pass } = getPanelConfig();
    const { cookie: initCookie, csrf } = await fetchCsrfToken(u);
    const sessionCookie = await performLogin(u, username, pass, initCookie, csrf);

    if (sessionCookie) {
      _sessionCookie = sessionCookie;
      _csrfToken     = csrf;
      _loggedIn      = true;
    }

    return { reachable: true, loginOk: !!sessionCookie, csrfFound: !!csrf };
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e);
    return { reachable: false, loginOk: false, csrfFound: false, error: msg };
  }
}

// ── getPanelStatus (export) ───────────────────────────────────

export function getPanelStatus(): { configured: boolean; url: string; username: string } {
  const { url, username, password } = getPanelConfig();
  return { configured: !!(url && password), url, username };
}

// ── clearXuiSession (export — برای debug) ────────────────────

export function clearXuiSession(): void {
  resetSession();
}

// ── xuiAddClient (export) ─────────────────────────────────────

export interface XuiNewClient {
  email: string;
  subId: string;
  subLink: string;
  inboundId: number;
}

export async function xuiAddClient(
  inboundId: number,
  email: string,
  trafficGb: number = 0,
  expireDays: number = 30,
  limitIp: number = 0,
  tgId: number = 0,
): Promise<XuiNewClient | null> {
  const { url } = getPanelConfig();
  if (!url) return null;

  const subId = Array.from(crypto.getRandomValues(new Uint8Array(8)))
    .map(b => b.toString(16).padStart(2, "0")).join("");

  const totalBytes = trafficGb > 0 ? trafficGb * 1024 * 1024 * 1024 : 0;
  const expiryTs   = expireDays > 0 ? Date.now() + expireDays * 86400 * 1000 : 0;

  const payload = {
    client: { email, totalGB: totalBytes, expiryTime: expiryTs, tgId, limitIp, enable: true, subId, reset: 0 },
    inboundIds: [inboundId],
  };

  const res = await xuiFetchWithSession(`${url}/panel/api/clients/add`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res || !res.ok) return null;
  const data = await res.json() as { success?: boolean };
  if (!data.success) return null;

  // لینک اشتراک — حذف webBasePath از انتهای PANEL_URL
  const subBase = url.replace(/\/[a-zA-Z0-9_-]{10,}$/, "");
  const subLink = `${subBase}/sub/${subId}`;
  return { email, subId, subLink, inboundId };
}
