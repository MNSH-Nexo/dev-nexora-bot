/**
 * lib/xui.ts — v3 (Patched for VPS stability)
 * کلاینت مرکزی برای اتصال به پنل 3X-UI
 *
 * تغییرات v3:
 *   - Login از هر دو روش JSON و form-encoded امتحان می‌کند (بعضی نسخه‌های 3X-UI)
 *   - redirect: manual برای جلوگیری از گم شدن Set-Cookie header
 *   - timeout افزایش یافته به 20 ثانیه
 *   - retry خودکار یک‌بار اگه login fail شد
 *   - لاگ داخلی برای debug آسان‌تر
 */

// ── config ────────────────────────────────────────────────────

function getPanelConfig() {
  const url      = (process.env.PANEL_URL      ?? "").trim().replace(/\/$/, "");
  const username = (process.env.PANEL_USERNAME ?? "admin").trim();
  const password = (process.env.PANEL_PASSWORD ?? "").trim();
  return { url, username, password };
}

// ── TLS bypass ────────────────────────────────────────────────

function withTlsBypass<T>(fn: () => Promise<T>): Promise<T> {
  const prev = process.env.NODE_TLS_REJECT_UNAUTHORIZED;
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  return fn().finally(() => {
    if (prev === undefined) delete process.env.NODE_TLS_REJECT_UNAUTHORIZED;
    else process.env.NODE_TLS_REJECT_UNAUTHORIZED = prev;
  });
}

// ── cookie helpers ────────────────────────────────────────────

function extractCookies(res: Response): string {
  // روش ۱: getSetCookie (Node 18+)
  if (typeof res.headers.getSetCookie === "function") {
    const cookies = res.headers.getSetCookie();
    if (cookies.length > 0) {
      return cookies.map((c: string) => c.split(";")[0]).join("; ");
    }
  }
  // روش ۲: set-cookie header مستقیم
  const single = res.headers.get("set-cookie") ?? "";
  if (single) return single.split(";")[0];
  return "";
}

function mergeCookies(base: string, override: string): string {
  if (!base) return override;
  if (!override) return base;
  if (base === override) return base;
  try {
    const basePairs   = Object.fromEntries(base.split(";").map(s => { const [k,...v]=s.trim().split("="); return [k.trim(), v.join("=")] as [string,string]; }));
    const overPairs   = Object.fromEntries(override.split(";").map(s => { const [k,...v]=s.trim().split("="); return [k.trim(), v.join("=")] as [string,string]; }));
    const merged = { ...basePairs, ...overPairs };
    return Object.entries(merged).filter(([k]) => k).map(([k, v]) => v ? `${k}=${v}` : k).join("; ");
  } catch {
    return override || base;
  }
}

// ── CSRF token parser ─────────────────────────────────────────

function extractCsrfToken(html: string): string {
  const m = html.match(/<meta\s+name=["']csrf-token["']\s+content=["']([^"']+)["']/i)
         ?? html.match(/<meta\s+content=["']([^"']+)["']\s+name=["']csrf-token["']/i)
         ?? html.match(/csrfToken['":\s]+["']([a-zA-Z0-9_-]{20,})["']/i);
  return m?.[1] ?? "";
}

// ── module-level session singleton ───────────────────────────

let _sessionCookie = "";
let _csrfToken     = "";
let _loggedIn      = false;
let _lastLoginAt   = 0;

function resetSession() {
  _sessionCookie = "";
  _csrfToken     = "";
  _loggedIn      = false;
  _lastLoginAt   = 0;
}

// ── Step 1: دریافت CSRF token ─────────────────────────────────

async function fetchCsrfToken(panelUrl: string): Promise<{ cookie: string; csrf: string }> {
  return withTlsBypass(async () => {
    try {
      const res = await fetch(`${panelUrl}/`, {
        method:  "GET",
        redirect: "manual",   // جلوگیری از دنبال کردن redirect که Set-Cookie را گم می‌کند
        headers: {
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept-Language": "en-US,en;q=0.9",
        },
        signal: AbortSignal.timeout(20_000),
      });
      const initialCookie = extractCookies(res);

      // اگه redirect بود، URL جدید را دنبال کن ولی cookie را نگه دار
      if (res.status >= 300 && res.status < 400) {
        const location = res.headers.get("location") ?? "";
        if (location) {
          try {
            const res2 = await fetch(location.startsWith("http") ? location : `${panelUrl}${location}`, {
              headers: {
                Accept: "text/html,*/*",
                "User-Agent": "Mozilla/5.0",
                ...(initialCookie ? { Cookie: initialCookie } : {}),
              },
              signal: AbortSignal.timeout(20_000),
            });
            const html2 = await res2.text();
            const moreCookies = extractCookies(res2);
            return { cookie: mergeCookies(initialCookie, moreCookies), csrf: extractCsrfToken(html2) };
          } catch { /* ignore */ }
        }
      }

      const html = await res.text();
      return { cookie: initialCookie, csrf: extractCsrfToken(html) };
    } catch {
      return { cookie: "", csrf: "" };
    }
  });
}

// ── Step 2: POST /login ───────────────────────────────────────
// 3X-UI نسخه‌های مختلف: بعضی JSON می‌خوان، بعضی form-encoded

async function performLogin(
  panelUrl: string,
  username: string,
  password: string,
  initialCookie: string,
  csrfToken: string,
): Promise<string | null> {
  return withTlsBypass(async () => {
    const baseHeaders: Record<string, string> = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Origin":   panelUrl,
      "Referer":  `${panelUrl}/`,
    };
    if (initialCookie) baseHeaders["Cookie"] = initialCookie;
    if (csrfToken)     baseHeaders["X-CSRF-Token"] = csrfToken;

    // روش ۱: JSON (نسخه‌های جدید 3X-UI)
    const tryJson = async (): Promise<string | null> => {
      const res = await fetch(`${panelUrl}/login`, {
        method:   "POST",
        redirect: "manual",
        headers:  { ...baseHeaders, "Content-Type": "application/json", Accept: "application/json" },
        body:     JSON.stringify({ username, password }),
        signal:   AbortSignal.timeout(20_000),
      });

      const setCookie = extractCookies(res);

      // موفق: cookie دریافت شد
      if (setCookie) return mergeCookies(initialCookie, setCookie);

      // redirect بعد از login — cookie ممکنه توی redirect باشه
      if (res.status >= 300 && res.status < 400 && !setCookie) {
        // try to get body of redirect target for more cookies
        const loc = res.headers.get("location") ?? "";
        if (loc) {
          try {
            const res2 = await fetch(loc.startsWith("http") ? loc : `${panelUrl}${loc}`, {
              redirect: "manual",
              headers: { ...baseHeaders, Cookie: initialCookie },
              signal: AbortSignal.timeout(10_000),
            });
            const moreCookie = extractCookies(res2);
            if (moreCookie) return mergeCookies(initialCookie, moreCookie);
          } catch { /* ignore */ }
        }
      }

      // بررسی body: اگه success:true بود ولی cookie نداشت
      if (res.ok || res.status === 302) {
        try {
          const body = await res.text();
          if (body.includes('"success":true') || body.includes("'success':true")) {
            // login موفق بود ولی cookie در response نبود — session cookie همان initial است
            return initialCookie || null;
          }
        } catch { /* ignore */ }
      }

      return null;
    };

    // روش ۲: form-encoded (نسخه‌های قدیمی‌تر 3X-UI)
    const tryForm = async (): Promise<string | null> => {
      const res = await fetch(`${panelUrl}/login`, {
        method:   "POST",
        redirect: "manual",
        headers:  {
          ...baseHeaders,
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "text/html,application/xhtml+xml,*/*",
        },
        body: new URLSearchParams({ username, password }).toString(),
        signal: AbortSignal.timeout(20_000),
      });

      const setCookie = extractCookies(res);
      if (setCookie) return mergeCookies(initialCookie, setCookie);
      return null;
    };

    // اول JSON امتحان می‌کنیم، اگه کار نکرد form-encoded
    const jsonResult = await tryJson();
    if (jsonResult) return jsonResult;
    return await tryForm();
  });
}

// ── xuiLogin (export) ─────────────────────────────────────────

export async function xuiLogin(): Promise<string | null> {
  const { url, username, password } = getPanelConfig();
  if (!url || !password) return null;

  try {
    const { cookie: initCookie, csrf } = await fetchCsrfToken(url);
    const sessionCookie = await performLogin(url, username, password, initCookie, csrf);
    if (!sessionCookie) return null;

    _sessionCookie = sessionCookie;
    _csrfToken     = csrf;
    _loggedIn      = true;
    _lastLoginAt   = Date.now();
    return sessionCookie;
  } catch {
    resetSession();
    return null;
  }
}

// ── fetch wrapper با session ──────────────────────────────────

async function xuiFetchWithSession(
  url: string,
  init: RequestInit = {},
): Promise<Response | null> {
  // re-login اگه session قدیمی‌تر از 30 دقیقه است
  const sessionAge = Date.now() - _lastLoginAt;
  if (!_loggedIn || sessionAge > 30 * 60 * 1000) {
    const ok = await xuiLogin();
    if (!ok) return null;
  }

  return withTlsBypass(async () => {
    const { url: panelUrl } = getPanelConfig();
    const headers: Record<string, string> = {
      ...(init.headers as Record<string, string> ?? {}),
      "Cookie":     _sessionCookie,
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Referer":    `${panelUrl}/`,
    };
    if (_csrfToken) headers["X-CSRF-Token"] = _csrfToken;

    const res = await fetch(url, {
      ...init,
      headers,
      signal: init.signal ?? AbortSignal.timeout(20_000),
    });

    // re-login روی 401 یا 403
    if (res.status === 401 || res.status === 403) {
      resetSession();
      const ok = await xuiLogin();
      if (!ok) return null;
      return withTlsBypass(() => fetch(url, {
        ...init,
        headers: {
          ...(init.headers as Record<string, string> ?? {}),
          Cookie:         _sessionCookie,
          "X-CSRF-Token": _csrfToken,
          "User-Agent":   "Mozilla/5.0",
        },
        signal: AbortSignal.timeout(20_000),
      }));
    }

    return res;
  });
}

// ── xuiGetInbounds (export) ───────────────────────────────────

export async function xuiGetInbounds(): Promise<Array<Record<string, unknown>> | null> {
  const { url } = getPanelConfig();
  if (!url) return null;

  try {
    const res = await xuiFetchWithSession(`${url}/panel/api/inbounds/list`, {
      headers: { Accept: "application/json" },
    });
    if (!res || !res.ok) return null;

    const data = await res.json() as { success: boolean; obj?: unknown[] };
    if (!data.success) return null;
    return (data.obj as Array<Record<string, unknown>>) ?? null;
  } catch {
    return null;
  }
}

// ── xuiGetServerStatus (export) ──────────────────────────────

export type XuiServerStatus = {
  cpu: number;
  cpuCores: number;
  mem:  { used: number; total: number };
  swap: { used: number; total: number };
  disk: { used: number; total: number };
  uptime:      number;
  loads:       number[];
  xrayState:   string;
  xrayVersion: string;
  panelVersion: string;
  netIO:    { up: number; down: number };
  tcpCount: number;
  udpCount: number;
};

export async function xuiGetServerStatus(): Promise<XuiServerStatus | null> {
  const { url } = getPanelConfig();
  if (!url) return null;

  try {
    const res = await xuiFetchWithSession(`${url}/panel/api/server/status`, {
      headers: { Accept: "application/json" },
    });
    if (!res || !res.ok) return null;

    const data = await res.json() as { success: boolean; obj?: Record<string, unknown> };
    if (!data.success || !data.obj) return null;

    const o    = data.obj;
    const mem  = o.mem  as { current: number; total: number } | undefined;
    const swap = o.swap as { current: number; total: number } | undefined;
    const disk = o.disk as { current: number; total: number } | undefined;
    const xray = o.xray as { state: string; version: string } | undefined;
    const netIO = o.netIO as { up: number; down: number } | undefined;

    return {
      cpu:      typeof o.cpu === "number" ? Math.round(o.cpu) : 0,
      cpuCores: typeof o.cpuCores === "number" ? o.cpuCores : 1,
      mem:  { used: mem?.current  ?? 0, total: mem?.total  ?? 0 },
      swap: { used: swap?.current ?? 0, total: swap?.total ?? 0 },
      disk: { used: disk?.current ?? 0, total: disk?.total ?? 0 },
      uptime:       typeof o.uptime === "number" ? o.uptime : 0,
      loads:        Array.isArray(o.loads) ? (o.loads as number[]) : [0, 0, 0],
      xrayState:    xray?.state   ?? "unknown",
      xrayVersion:  xray?.version ?? "",
      panelVersion: typeof o.panelVersion === "string" ? o.panelVersion : "",
      netIO:    { up: netIO?.up ?? 0, down: netIO?.down ?? 0 },
      tcpCount: typeof o.tcpCount === "number" ? o.tcpCount : 0,
      udpCount: typeof o.udpCount === "number" ? o.udpCount : 0,
    };
  } catch {
    return null;
  }
}

// ── xuiPing (export) ──────────────────────────────────────────

export async function xuiPing(): Promise<{
  reachable: boolean;
  loginOk:   boolean;
  csrfFound: boolean;
  error?:    string;
}> {
  const { url, password } = getPanelConfig();
  if (!url)      return { reachable: false, loginOk: false, csrfFound: false, error: "PANEL_URL not set" };
  if (!password) return { reachable: false, loginOk: false, csrfFound: false, error: "PANEL_PASSWORD not set" };

  try {
    const { url: u, username, password: pass } = getPanelConfig();
    const { cookie: initCookie, csrf } = await fetchCsrfToken(u);
    const sessionCookie = await performLogin(u, username, pass, initCookie, csrf);

    if (sessionCookie) {
      _sessionCookie = sessionCookie;
      _csrfToken     = csrf;
      _loggedIn      = true;
      _lastLoginAt   = Date.now();
    }

    return { reachable: true, loginOk: !!sessionCookie, csrfFound: !!csrf };
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e);
    return { reachable: false, loginOk: false, csrfFound: false, error: msg };
  }
}

// ── getPanelStatus (export) ───────────────────────────────────

export function getPanelStatus(): { configured: boolean; url: string; username: string } {
  const { url, username, password } = getPanelConfig();
  return { configured: !!(url && password), url, username };
}

// ── clearXuiSession (export) ─────────────────────────────────

export function clearXuiSession(): void {
  resetSession();
}

// ── xuiAddClient (export) ─────────────────────────────────────

export interface XuiNewClient {
  email:     string;
  subId:     string;
  subLink:   string;
  inboundId: number;
}

export async function xuiAddClient(
  inboundId: number,
  email:     string,
  trafficGb: number = 0,
  expireDays: number = 30,
  limitIp:   number = 0,
  tgId:      number = 0,
): Promise<XuiNewClient | null> {
  const { url } = getPanelConfig();
  if (!url) return null;

  const subId = Array.from(crypto.getRandomValues(new Uint8Array(8)))
    .map(b => b.toString(16).padStart(2, "0")).join("");

  const totalBytes = trafficGb  > 0 ? trafficGb  * 1024 * 1024 * 1024 : 0;
  const expiryTs   = expireDays > 0 ? Date.now() + expireDays * 86400 * 1000 : 0;

  const payload = {
    client: { email, totalGB: totalBytes, expiryTime: expiryTs, tgId, limitIp, enable: true, subId, reset: 0 },
    inboundIds: [inboundId],
  };

  const res = await xuiFetchWithSession(`${url}/panel/api/clients/add`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(payload),
  });

  if (!res || !res.ok) return null;
  const data = await res.json() as { success?: boolean };
  if (!data.success) return null;

  const subBase = url.replace(/\/[a-zA-Z0-9_-]{10,}$/, "");
  const subLink = `${subBase}/sub/${subId}`;
  return { email, subId, subLink, inboundId };
}
