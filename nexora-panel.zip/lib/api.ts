/**
 * lib/api.ts
 * helper برای fetch با webpath اتوماتیک
 *
 * استراتژی سه‌مرحله‌ای برای پیدا کردن webpath:
 *  1. cache در sessionStorage (سریع‌ترین)
 *  2. پیدا کردن از pathname مرورگر (/dashboard یا /login)
 *  3. دریافت از سرور via /api/auth/webpath (fallback)
 *
 * مشکل قبلی: DynamicHead در layout قبل از /login یا /dashboard لود میشد
 * و pathname هنوز /webpath/ بود — پس prefix پیدا نمیشد → /api/brand بدون prefix
 */

const CACHE_KEY = "nexora_webpath";

/** webpath cached از sessionStorage */
function getCached(): string | null {
  try { return sessionStorage.getItem(CACHE_KEY); } catch { return null; }
}

function setCached(v: string): void {
  try { sessionStorage.setItem(CACHE_KEY, v); } catch { /* ignore */ }
}

/** webpath رو از URL مرورگر می‌گیره
 *
 * وقتی middleware rewrite می‌کنه (مثلاً /secret/login → /login)
 * URL در مرورگر همچنان /secret/login هست — پس می‌تونیم webpath رو بخونیم.
 *
 * وقتی root است (/secret/ یا /secret) و هنوز redirect نشده،
 * pathname تنها یه segment داره → اون همون webpath است.
 */
function fromPathname(): string {
  if (typeof window === "undefined") return "";
  const p = window.location.pathname;

  // حالت ۱: یه segment شناخته‌شده داخلی پیدا کن
  for (const seg of ["/dashboard", "/login", "/nexora"]) {
    const idx = p.indexOf(seg);
    if (idx > 0) return p.slice(0, idx);
  }

  // حالت ۲: pathname = /webpath یا /webpath/ (root)
  // مرورگر هنوز روی root webpath هست، قبل از redirect به /login
  const clean = p.replace(/\/$/, "");          // حذف trailing slash
  const parts = clean.split("/").filter(Boolean);
  if (parts.length === 1) return "/" + parts[0]; // /secret → prefix = /secret

  return "";
}

/** webpath رو از server میگیره — از header x-web-path یا /api/auth/webpath */
async function fromServer(): Promise<string> {
  try {
    // middleware یه x-web-path header به همه response‌ها اضافه می‌کنه
    // اگه نبود، /api/auth/webpath رو صدا می‌زنیم
    const res = await fetch("/api/auth/webpath", { cache: "no-store" });
    const headerPath = res.headers.get("x-web-path") ?? "";
    if (headerPath) return headerPath;
    if (!res.ok) return "";
    const { webPath } = await res.json() as { webPath: string };
    return webPath ?? "";
  } catch { return ""; }
}

/** webpath رو می‌گیره — sync، از cache یا pathname */
export function getWebPrefix(): string {
  if (typeof window === "undefined") return "";

  // ۱. cache
  const cached = getCached();
  if (cached !== null) return cached;

  // ۲. pathname
  const fromPath = fromPathname();
  if (fromPath) {
    setCached(fromPath);
    return fromPath;
  }

  return "";
}

/**
 * webpath رو async می‌گیره — برای اولین بار از server fetch می‌کنه
 * بعد cache میکنه
 */
export async function getWebPrefixAsync(): Promise<string> {
  if (typeof window === "undefined") return "";

  // ۱. cache
  const cached = getCached();
  if (cached !== null) return cached;

  // ۲. pathname
  const fromPath = fromPathname();
  if (fromPath) {
    setCached(fromPath);
    return fromPath;
  }

  // ۳. server fallback
  const fromSrv = await fromServer();
  setCached(fromSrv);
  return fromSrv;
}

/** fetch با webpath prefix اتوماتیک (sync — از cache/pathname) */
export function apiFetch(path: string, init?: RequestInit): Promise<Response> {
  const prefix = getWebPrefix();
  return fetch(prefix + path, init);
}

/** fetch با webpath prefix اتوماتیک (async — اگه prefix نبود از server می‌گیره) */
export async function apiFetchAsync(path: string, init?: RequestInit): Promise<Response> {
  const prefix = await getWebPrefixAsync();
  return fetch(prefix + path, init);
}
